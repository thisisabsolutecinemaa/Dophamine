package com.dophamine.voicechanger;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XSharedPreferences;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.callbacks.XC_LoadPackage;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.MediaRecorder;
import java.nio.ByteBuffer;

public class MainHook implements IXposedHookLoadPackage {
    private static final String TAG = "Dophamine";
    private XSharedPreferences prefs;

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {
        // ЗАЩИТА 1: SYSTEM GUARD
        if (lpparam.packageName.equals("android") || 
            lpparam.packageName.equals("com.android.systemui") || 
            lpparam.packageName.equals("com.dophamine.voicechanger")) return;

        initPrefs();

        try {
            // --- ХУКИ AUDIORECORD (Микрофон) ---
            hookMethod(AudioRecord.class, "read", new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam param) { processHook(param, true); }
            });
            hookMethod(AudioRecord.class, "read", new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam param) { processHook(param, true); }
            });

            // --- ХУКИ AUDIOTRACK (Динамик/VoIP) ---
            hookMethod(AudioTrack.class, "write", new XC_MethodHook() {
                @Override protected void beforeHookedMethod(MethodHookParam param) { processHook(param, false); }
            });
            hookMethod(AudioTrack.class, "write", new XC_MethodHook() {
                @Override protected void beforeHookedMethod(MethodHookParam param) { processHook(param, false); }
            });

            // --- ХУК MEDIARECORDER ---
            hookMethod(MediaRecorder.class, "start", new XC_MethodHook() {
                @Override protected void beforeHookedMethod(MethodHookParam param) {
                    reloadPrefs();
                    XposedBridge.log(TAG + ": MediaRecorder started in " + lpparam.packageName);
                }
            });

        } catch (Throwable t) {
            XposedBridge.log(TAG + ": Hook setup failed: " + t.getMessage());
        }
    }

    private void hookMethod(Class<?> clazz, String method, XC_MethodHook hook) {
        try { XposedBridge.hookAllMethods(clazz, method, hook); } 
        catch (Throwable ignored) {}
    }

    private void initPrefs() {
        prefs = new XSharedPreferences("com.dophamine.voicechanger", MainActivity.PREFS_NAME);
        prefs.makeWorldReadable();
    }

    private void reloadPrefs() {
        if (prefs != null) prefs.reload();
    }

    private void processHook(XC_MethodHook.MethodHookParam param, boolean isRead) {
        // ЗАЩИТА 2: NULL GUARD
        if (param == null || param.args == null || param.args.length < 2) return;
        
        reloadPrefs();
        if (prefs == null || !prefs.getBoolean("master", true)) return;

        Object bufferArg = param.args[0];
        int bytesReadOrWritten = 0;
        
        if (isRead) {
            if (param.result == null || !(param.result instanceof Integer)) return;
            bytesReadOrWritten = (int) param.result;
        } else {
            if (!(param.args[2] instanceof Integer)) return;
            bytesReadOrWritten = (int) param.args[2];
        }

        if (bytesReadOrWritten <= 0) return;
        int offset = (param.args[1] instanceof Integer) ? (int) param.args[1] : 0;

        // Обработка разных типов буферов
        if (bufferArg instanceof byte[]) {
            processByteArray((byte[]) bufferArg, offset, bytesReadOrWritten);
        } else if (bufferArg instanceof short[]) {
            processShortArray((short[]) bufferArg, offset, bytesReadOrWritten / 2);
        } else if (bufferArg instanceof float[]) {
            processFloatArray((float[]) bufferArg, offset, bytesReadOrWritten / 4);
        } else if (bufferArg instanceof ByteBuffer) {
            processByteBuffer((ByteBuffer) bufferArg, bytesReadOrWritten);
        }
    }

    private void processByteArray(byte[] buffer, int offset, int length) {
        // ЗАЩИТА 3: BOUNDS GUARD
        if (buffer == null || offset < 0 || length <= 0 || offset + length > buffer.length) return;
        
        for (int i = offset; i < offset + length; i++) {
            float sample = (buffer[i] - 128) / 128.0f;
            sample = AudioProcessor.process(sample);
            buffer[i] = (byte) ((sample * 128.0f) + 128);
        }
    }

    private void processShortArray(short[] buffer, int offset, int length) {
        if (buffer == null || offset < 0 || length <= 0 || offset + length > buffer.length) return;
        
        for (int i = offset; i < offset + length; i++) {
            float sample = buffer[i] / 32768.0f;
            sample = AudioProcessor.process(sample);
            buffer[i] = (short) (sample * 32767.0f);
        }
    }

    private void processFloatArray(float[] buffer, int offset, int length) {
        if (buffer == null || offset < 0 || length <= 0 || offset + length > buffer.length) return;
        
        for (int i = offset; i < offset + length; i++) {
            buffer[i] = AudioProcessor.process(buffer[i]);
        }
    }

    private void processByteBuffer(ByteBuffer bb, int length) {
        if (bb == null || length <= 0) return;
        try {
            byte[] temp = new byte[length];
            int pos = bb.position();
            bb.get(temp, 0, length);
            processByteArray(temp, 0, length);
            bb.position(pos);
            bb.put(temp, 0, length);
        } catch (Throwable ignored) {}
    }
}
