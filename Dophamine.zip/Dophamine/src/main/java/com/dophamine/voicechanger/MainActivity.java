package com.dophamine.voicechanger;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Switch;
import android.widget.SeekBar;
import android.widget.CompoundButton;

public class MainActivity extends Activity {
    public static final String PREFS_NAME = "dophamine_prefs";
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        // MODE_WORLD_READABLE нужен, чтобы LSPosed мог читать настройки из другого процесса
        prefs = getSharedPreferences(PREFS_NAME, MODE_WORLD_READABLE);

        Switch switchMaster = findViewById(R.id.switch_master);
        Switch switchBarrel = findViewById(R.id.switch_barrel);
        Switch switchBarrier = findViewById(R.id.switch_barrier);
        SeekBar seekBarrel = findViewById(R.id.seek_barrel_resonance);
        SeekBar seekGain = findViewById(R.id.seek_barrier_gain);

        // Загрузка сохраненных значений
        switchMaster.setChecked(prefs.getBoolean("master", true));
        switchBarrel.setChecked(prefs.getBoolean("barrel", true));
        switchBarrier.setChecked(prefs.getBoolean("barrier", true));
        seekBarrel.setProgress(prefs.getInt("resonance", 75));
        seekGain.setProgress(prefs.getInt("gain", 50));

        // Слушатели изменений
        CompoundButton.OnCheckedChangeListener listener = (buttonView, isChecked) -> savePrefs();
        switchMaster.setOnCheckedChangeListener(listener);
        switchBarrel.setOnCheckedChangeListener(listener);
        switchBarrier.setOnCheckedChangeListener(listener);

        SeekBar.OnSeekBarChangeListener seekListener = new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) { savePrefs(); }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        };
        seekBarrel.setOnSeekBarChangeListener(seekListener);
        seekGain.setOnSeekBarChangeListener(seekListener);
    }

    private void savePrefs() {
        SharedPreferences.Editor editor = prefs.edit();
        editor.putBoolean("master", ((Switch)findViewById(R.id.switch_master)).isChecked());
        editor.putBoolean("barrel", ((Switch)findViewById(R.id.switch_barrel)).isChecked());
        editor.putBoolean("barrier", ((Switch)findViewById(R.id.switch_barrier)).isChecked());
        editor.putInt("resonance", ((SeekBar)findViewById(R.id.seek_barrel_resonance)).getProgress());
        editor.putInt("gain", ((SeekBar)findViewById(R.id.seek_barrier_gain)).getProgress());
        editor.apply();
    }
}
