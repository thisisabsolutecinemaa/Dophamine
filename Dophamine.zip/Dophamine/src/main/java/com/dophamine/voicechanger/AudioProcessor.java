package com.dophamine.voicechanger;

import de.robv.android.xposed.XSharedPreferences;

public class AudioProcessor {
    private static final int DELAY_SAMPLES = 1200; // Увеличенный буфер для глубокой бочки
    private static float[] delayBuffer = new float[DELAY_SAMPLES];
    private static int delayIndex = 0;
    private static float prevSample = 0f;
    private static float dcFilterPrevIn = 0f;
    private static float dcFilterPrevOut = 0f;

    public static float process(float sample) {
        // Читаем настройки напрямую из памяти (XSharedPreferences кешируется)
        boolean barrelOn = PrefsManager.getBoolean("barrel", true);
        boolean barrierOn = PrefsManager.getBoolean("barrier", true);
        float resonance = PrefsManager.getInt("resonance", 75) / 100.0f;
        float gainMultiplier = 1.0f + (PrefsManager.getInt("gain", 50) / 10.0f); // До x11

        // 1. ЭФФЕКТ БОЧКИ
        if (barrelOn) {
            float lowPass = (prevSample * resonance) + (sample * (1.0f - resonance));
            float delayed = delayBuffer[delayIndex];
            sample = lowPass + (delayed * 0.7f); // Более сильное эхо
            
            delayBuffer[delayIndex] = sample;
            delayIndex = (delayIndex + 1) % DELAY_SAMPLES;
            prevSample = lowPass;
        }

        // 2. СЛОМ ЗВУКОВОГО БАРЬЕРА
        if (barrierOn) {
            sample = sample * gainMultiplier;
            sample = (float) Math.tanh(sample); // Soft clip overdrive
        }

        // 3. DC OFFSET FILTER (Защита динамиков от сгорания)
        // При экстремальном усилении появляется постоянный ток, который рвет мембрану.
        // Этот фильтр его убирает, оставляя только сам "сломанный" звук.
        float filtered = sample - dcFilterPrevIn + (0.995f * dcFilterPrevOut);
        dcFilterPrevIn = sample;
        dcFilterPrevOut = filtered;
        sample = filtered;

        // ЗАЩИТА 5: MATH & HARD CLIP GUARD
        if (Float.isNaN(sample) || Float.isInfinite(sample)) {
            sample = 0f; // Если математика сломалась - тишина, а не краш
        }
        if (sample > 1.0f) sample = 1.0f;
        if (sample < -1.0f) sample = -1.0f;

        return sample;
    }
}
