package com.dophamine.voicechanger;

import de.robv.android.xposed.XSharedPreferences;

public class PrefsManager {
    private static XSharedPreferences prefs;

    public static void init() {
        prefs = new XSharedPreferences("com.dophamine.voicechanger", MainActivity.PREFS_NAME);
        prefs.makeWorldReadable();
    }

    private static void reload() {
        if (prefs == null) init();
        if (prefs != null) prefs.reload();
    }

    public static boolean getBoolean(String key, boolean def) {
        reload();
        return prefs != null ? prefs.getBoolean(key, def) : def;
    }

    public static int getInt(String key, int def) {
        reload();
        return prefs != null ? prefs.getInt(key, def) : def;
    }
}
