package com.dophamine.voice.dsp;

/** Small shared helpers for the DSP chain. */
final class Dsp {
    private Dsp() {}

    static float dbToLin(float db) {
        return (float) Math.pow(10.0, db / 20.0);
    }

    /** One-pole smoothing coefficient for a time constant given in seconds. */
    static float coef(int sr, double seconds) {
        return (float) (1.0 - Math.exp(-1.0 / (seconds * sr)));
    }

    static float clamp01(float v) {
        if (v != v) return 0f;
        return v < 0f ? 0f : (v > 1f ? 1f : v);
    }

    /** Milliseconds to samples (never less than 2). */
    static int ms(int sr, double ms) {
        return Math.max(2, (int) Math.round(ms * sr / 1000.0));
    }

    /** Flush denormals / tiny values to zero so feedback loops die out cleanly. */
    static float flush(float v) {
        return (v < 1e-20f && v > -1e-20f) ? 0f : v;
    }
}
