package com.dophamine.voice.dsp;

import java.nio.ByteBuffer;
import java.util.Map;
import java.util.WeakHashMap;

/**
 * Glue between raw AudioRecord buffers (short[], byte[], float[], ByteBuffer) and the engine.
 * Keeps one engine per AudioRecord instance (weak keys, so released recorders disappear).
 * Every method returns the number of samples that were processed, or -1 when the buffer was
 * left untouched (disabled, neutral, unsupported format, bad arguments).
 */
public final class BufferProcessor {
    public static final int ENC_PCM_16BIT = 2;
    public static final int ENC_PCM_8BIT = 3;
    public static final int ENC_PCM_FLOAT = 4;
    public static final int MAX_CHANNELS = 8;

    private static final float INV_16 = 1f / 32768f;

    private static final class State {
        DophamineEngine engine;
        int sr;
        int ch;
        boolean idle;
        float[] fbuf = new float[0];
        byte[] bbuf = new byte[0];

        float[] floats(int n) {
            if (fbuf.length < n) fbuf = new float[n + (n >> 1) + 16];
            return fbuf;
        }

        byte[] bytes(int n) {
            if (bbuf.length < n) bbuf = new byte[n + (n >> 1) + 16];
            return bbuf;
        }
    }

    private final Map<Object, State> states = new WeakHashMap<Object, State>();

    /** Call when the recorder restarts or while the effect is off: next use starts from a clean state. */
    public void markIdle(Object key) {
        if (key == null) return;
        synchronized (states) {
            State s = states.get(key);
            if (s != null) s.idle = true;
        }
    }

    private State get(Object key) {
        synchronized (states) {
            State s = states.get(key);
            if (s == null) {
                s = new State();
                states.put(key, s);
            }
            return s;
        }
    }

    /** Must be called with the State monitor held. */
    private static void prepare(State s, int sr, int ch, DspParams p) {
        if (sr < 8000 || sr > 192000) sr = 48000;
        if (s.engine == null || s.sr != sr || s.ch != ch) {
            s.engine = new DophamineEngine(sr, ch);
            s.sr = sr;
            s.ch = ch;
            s.idle = false;
        }
        if (s.idle) {
            s.engine.reset();
            s.idle = false;
        }
        s.engine.setParams(p);
    }

    private boolean skip(Object key, DspParams p, int ch) {
        if (key == null || p == null) return true;
        if (!p.enabled || p.isNeutral()) {
            markIdle(key);
            return true;
        }
        return ch < 1 || ch > MAX_CHANNELS;
    }

    // ---------------------------------------------------------------- short[]

    public int processShorts(Object key, short[] data, int off, int count, int sr, int ch, DspParams p) {
        if (data == null || skip(key, p, ch)) return -1;
        if (off < 0 || count <= 0 || off >= data.length) return -1;
        if (count > data.length - off) count = data.length - off;
        int frames = count / ch;
        if (frames <= 0) return -1;
        int n = frames * ch;
        State s = get(key);
        synchronized (s) {
            prepare(s, sr, ch, p);
            float[] f = s.floats(n);
            for (int i = 0; i < n; i++) f[i] = data[off + i] * INV_16;
            s.engine.process(f, 0, frames);
            for (int i = 0; i < n; i++) data[off + i] = toShort(f[i]);
        }
        return n;
    }

    // ---------------------------------------------------------------- float[]

    public int processFloats(Object key, float[] data, int off, int count, int sr, int ch, DspParams p) {
        if (data == null || skip(key, p, ch)) return -1;
        if (off < 0 || count <= 0 || off >= data.length) return -1;
        if (count > data.length - off) count = data.length - off;
        int frames = count / ch;
        if (frames <= 0) return -1;
        int n = frames * ch;
        State s = get(key);
        synchronized (s) {
            prepare(s, sr, ch, p);
            float[] f = s.floats(n);
            System.arraycopy(data, off, f, 0, n);
            s.engine.process(f, 0, frames);
            System.arraycopy(f, 0, data, off, n);
        }
        return n;
    }

    // ---------------------------------------------------------------- byte[]

    /** @param len number of valid bytes starting at off (what read() returned). */
    public int processBytes(Object key, byte[] data, int off, int len, int enc, int sr, int ch, DspParams p) {
        if (data == null || bytesPerSample(enc) == 0 || skip(key, p, ch)) return -1;
        if (off < 0 || len <= 0 || off >= data.length) return -1;
        if (len > data.length - off) len = data.length - off;
        State s = get(key);
        synchronized (s) {
            prepare(s, sr, ch, p);
            return runBytes(s, data, off, len, enc, ch);
        }
    }

    // ---------------------------------------------------------------- ByteBuffer

    /**
     * AudioRecord.read(ByteBuffer, ...) always fills the buffer from index 0 and does not move
     * position/limit, so the first {@code len} bytes are processed and position/limit are kept.
     */
    public int processByteBuffer(Object key, ByteBuffer bb, int len, int enc, int sr, int ch, DspParams p) {
        if (bb == null || bytesPerSample(enc) == 0 || skip(key, p, ch)) return -1;
        if (len > bb.capacity()) len = bb.capacity();
        if (len <= 0) return -1;
        State s = get(key);
        synchronized (s) {
            try {
                prepare(s, sr, ch, p);
                byte[] tmp = s.bytes(len);
                ByteBuffer d = bb.duplicate();
                d.clear();
                d.get(tmp, 0, len);
                int n = runBytes(s, tmp, 0, len, enc, ch);
                if (n > 0) {
                    d.clear();
                    d.put(tmp, 0, len);
                }
                return n;
            } catch (RuntimeException e) { // read-only buffer etc.
                return -1;
            }
        }
    }

    // ---------------------------------------------------------------- internals

    private static int bytesPerSample(int enc) {
        if (enc == ENC_PCM_16BIT) return 2;
        if (enc == ENC_PCM_FLOAT) return 4;
        return 0; // 8-bit and exotic formats are passed through untouched
    }

    /** State monitor must be held and prepare() already called. */
    private static int runBytes(State s, byte[] b, int off, int len, int enc, int ch) {
        int bps = bytesPerSample(enc);
        int frames = (len / bps) / ch;
        if (frames <= 0) return -1;
        int n = frames * ch;
        float[] f = s.floats(n);
        if (enc == ENC_PCM_16BIT) {
            for (int i = 0, j = off; i < n; i++, j += 2) {
                f[i] = (short) ((b[j] & 0xFF) | (b[j + 1] << 8)) * INV_16;
            }
        } else {
            for (int i = 0, j = off; i < n; i++, j += 4) {
                int bits = (b[j] & 0xFF) | ((b[j + 1] & 0xFF) << 8)
                        | ((b[j + 2] & 0xFF) << 16) | ((b[j + 3] & 0xFF) << 24);
                f[i] = Float.intBitsToFloat(bits);
            }
        }
        s.engine.process(f, 0, frames);
        if (enc == ENC_PCM_16BIT) {
            for (int i = 0, j = off; i < n; i++, j += 2) {
                short v = toShort(f[i]);
                b[j] = (byte) v;
                b[j + 1] = (byte) (v >> 8);
            }
        } else {
            for (int i = 0, j = off; i < n; i++, j += 4) {
                int bits = Float.floatToRawIntBits(f[i]);
                b[j] = (byte) bits;
                b[j + 1] = (byte) (bits >> 8);
                b[j + 2] = (byte) (bits >> 16);
                b[j + 3] = (byte) (bits >> 24);
            }
        }
        return n;
    }

    public static short toShort(float f) {
        if (f != f) return 0;
        float v = f * 32767f;
        if (v > 32767f) v = 32767f;
        else if (v < -32768f) v = -32768f;
        return (short) Math.round(v);
    }
}
