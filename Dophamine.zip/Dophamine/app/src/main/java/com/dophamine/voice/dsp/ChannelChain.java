package com.dophamine.voice.dsp;

/**
 * One mono signal path: gate -> pitch -> barrel -> bass shelf -> loudness
 * -> sonic boom -> soft limiter.
 */
final class ChannelChain {
    private static final float GAIN_SMOOTH = 0.002f;

    private final int sr;
    private final Gate gate;
    private final PitchShifter pitch;
    private final BarrelReverb barrel;
    private final Biquad bass = new Biquad();
    private final BoomThump boom;
    private final float blendStep;

    private boolean configured;
    private boolean bassOn;
    private float boomAmt;
    private float pitchBlend;
    private float pitchTarget;
    private float gainCur = 1f;
    private float gainTarget = 1f;

    ChannelChain(int sr) {
        this.sr = sr;
        gate = new Gate(sr);
        pitch = new PitchShifter(sr);
        barrel = new BarrelReverb(sr);
        boom = new BoomThump(sr);
        blendStep = 1f / Math.max(1, Math.round(sr * 0.02f));
    }

    void configure(DspParams p) {
        gate.configure(p.gateOn(), p.gateDb);
        pitch.setSemitones(p.pitchSemitones);
        pitchTarget = Math.abs(p.pitchSemitones) >= 0.02f ? 1f : 0f;
        barrel.configure(p.barrelMix, p.barrelSize);

        boolean wasBass = bassOn;
        bassOn = p.bassDb >= 0.05f;
        if (bassOn) {
            bass.lowShelf(sr, 110.0, p.bassDb);
            if (!wasBass) bass.reset();
        }

        boolean wasBoom = boomAmt > 0f;
        boomAmt = p.boom >= 0.001f ? p.boom : 0f;
        if (boomAmt > 0f && !wasBoom) boom.reset();

        gainTarget = Dsp.dbToLin(p.loudnessDb);
        if (!configured) {
            gainCur = gainTarget;
            pitchBlend = pitchTarget;
            configured = true;
        }
    }

    /** Clears all audio state but keeps the configuration. */
    void reset() {
        gate.reset();
        pitch.reset();
        barrel.reset();
        bass.reset();
        boom.reset();
        gainCur = gainTarget;
        pitchBlend = pitchTarget;
    }

    float process(float in) {
        float x = gate.process(in);

        // The shifter always runs so its buffer is fresh; the blend ramps
        // smoothly between dry and shifted when the pitch is switched on/off.
        float shifted = pitch.process(x);
        if (pitchBlend < pitchTarget) {
            pitchBlend = Math.min(pitchTarget, pitchBlend + blendStep);
        } else if (pitchBlend > pitchTarget) {
            pitchBlend = Math.max(pitchTarget, pitchBlend - blendStep);
        }
        float y = x + (shifted - x) * pitchBlend;

        y = barrel.process(y);
        if (bassOn) y = bass.process(y);

        gainCur += (gainTarget - gainCur) * GAIN_SMOOTH;
        y *= gainCur;

        if (boomAmt > 0f) y += boom.process(x) * boomAmt * 0.9f;
        return Saturator.soft(y);
    }
}
