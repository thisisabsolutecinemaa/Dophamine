package com.dophamine.voice.dsp;

/**
 * Noise gate that sits at the very start of the chain. Without it +60 dB of
 * loudness would turn microphone hiss into a full-scale roar during pauses.
 * Peak follower + hold time + smoothed gain, so no chattering and no clicks.
 */
final class Gate {
    private final float atk;
    private final float rel;
    private final float openCoef;
    private final float closeCoef;
    private final int holdSamples;

    private boolean on;
    private float thr = 1f;
    private float env;
    private float g;
    private int hold;

    Gate(int sr) {
        atk = Dsp.coef(sr, 0.001);
        rel = Dsp.coef(sr, 0.050);
        openCoef = Dsp.coef(sr, 0.003);
        closeCoef = Dsp.coef(sr, 0.020);
        holdSamples = Math.round(sr * 0.08f);
    }

    void reset() {
        env = 0f;
        g = 0f;
        hold = 0;
    }

    void configure(boolean enable, float thresholdDb) {
        if (enable && !on) reset();
        on = enable;
        thr = Dsp.dbToLin(thresholdDb);
    }

    float process(float x) {
        if (!on) return x;
        float a = x < 0f ? -x : x;
        env += (a - env) * (a > env ? atk : rel);
        if (env >= thr) hold = holdSamples;
        else if (hold > 0) hold--;
        float target = hold > 0 ? 1f : 0f;
        g += (target - g) * (target > g ? openCoef : closeCoef);
        if (target == 0f && g < 1e-4f) g = 0f;
        return x * g;
    }
}
