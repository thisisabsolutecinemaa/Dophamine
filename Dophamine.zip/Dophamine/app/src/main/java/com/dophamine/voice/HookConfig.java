package com.dophamine.voice;

import com.dophamine.voice.dsp.DspParams;

import java.util.Collections;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;

import de.robv.android.xposed.XSharedPreferences;
import de.robv.android.xposed.XposedBridge;

/**
 * Settings as seen from inside a hooked app. A daemon thread re-reads the module's prefs every
 * ~0.7 s, so the audio thread only ever reads a volatile reference and never touches the disk.
 *
 * Note: XSharedPreferences loads the file in its constructor, so hasFileChanged() is false right
 * after creation. The first pass therefore reads the values unconditionally.
 */
final class HookConfig {
    private static volatile DspParams current = DspParams.DEFAULT;
    private static volatile boolean onlySelected;
    private static volatile Set<String> targets = Collections.emptySet();
    private static volatile boolean hasData;
    private static final AtomicBoolean STARTED = new AtomicBoolean(false);

    private HookConfig() {}

    static DspParams current() {
        return current;
    }

    /** True once real settings were read from the module's prefs. */
    static boolean hasData() {
        return hasData;
    }

    /** Should the voice be changed in this app? (no list = every app that is in the LSPosed scope) */
    static boolean allowed(String pkg) {
        return !onlySelected || (pkg != null && targets.contains(pkg));
    }

    static void start() {
        if (!STARTED.compareAndSet(false, true)) return;
        try {
            Thread t = new Thread(new Runnable() {
                @Override
                public void run() {
                    loop();
                }
            }, "dophamine-config");
            t.setDaemon(true);
            t.start();
        } catch (Throwable t) {
            XposedBridge.log("Dophamine: config thread failed, using defaults: " + t);
        }
    }

    private static void loop() {
        XSharedPreferences prefs = null;
        boolean gotData = false;
        boolean warned = false;
        int idle = 0;
        while (true) {
            try {
                // until real data arrives, re-open the prefs every ~5 s (file may not exist yet)
                if (prefs == null || (!gotData && ++idle >= 7)) {
                    idle = 0;
                    prefs = new XSharedPreferences(DophamineHook.SELF, Config.PREFS);
                    gotData = apply(prefs) || gotData;
                    if (!gotData && !warned) {
                        warned = true;
                        XposedBridge.log("Dophamine: settings not readable yet, using the 'Barrel' preset "
                                + "(open the Dophamine app once and keep the module enabled)");
                    }
                } else if (prefs.hasFileChanged()) {
                    prefs.reload();
                    gotData = apply(prefs) || gotData;
                }
            } catch (Throwable t) {
                if (!warned) {
                    warned = true;
                    XposedBridge.log("Dophamine: config error: " + t);
                }
            }
            try {
                Thread.sleep(700);
            } catch (InterruptedException e) {
                return;
            }
        }
    }

    /** @return true if the prefs contained data and the settings were updated. */
    private static boolean apply(XSharedPreferences prefs) {
        if (prefs.getAll().isEmpty()) return false;
        DspParams p = Config.fromPrefs(prefs);
        current = p;
        onlySelected = Config.onlySelected(prefs);
        targets = Collections.unmodifiableSet(Config.targets(prefs));
        hasData = true;
        XposedBridge.log("Dophamine: settings applied: pitch=" + p.pitchSemitones + " barrel=" + p.barrelMix
                + " loud=" + p.loudnessDb + "dB boom=" + p.boom + " enabled=" + p.enabled
                + " onlySelected=" + onlySelected + " targets=" + targets.size());
        return true;
    }
}
