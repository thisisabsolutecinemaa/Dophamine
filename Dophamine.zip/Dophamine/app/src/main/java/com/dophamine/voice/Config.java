package com.dophamine.voice;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;

import com.dophamine.voice.dsp.DspParams;

import java.util.HashSet;
import java.util.Set;

/** Preference keys, presets and the SharedPreferences -> DspParams mapping (shared by app and hook). */
public final class Config {
    public static final String PREFS = "dophamine_prefs";

    /** Private prefs with runtime state written by the app itself (last hooked app). */
    public static final String STATE_PREFS = "dophamine_state";
    public static final String ST_LAST_PKG = "last_pkg";
    public static final String ST_LAST_TIME = "last_time";
    public static final String ST_LAST_CFG = "last_cfg";
    public static final String ST_LAST_ALLOWED = "last_allowed";
    /** Broadcast the hook sends to the app when a hooked app starts recording. */
    public static final String ACTION_HOOKED = "com.dophamine.voice.HOOKED";

    public static final String K_ENABLED = "enabled";
    public static final String K_PITCH = "pitch";
    public static final String K_BARREL = "barrel";
    public static final String K_SIZE = "size";
    public static final String K_LOUD = "loud";
    public static final String K_BASS = "bass";
    public static final String K_BOOM = "boom";
    public static final String K_GATE = "gate";
    /** true = change the voice only in the apps from K_TARGETS; false = in every app that is in the LSPosed scope. */
    public static final String K_ONLY = "only_selected";
    public static final String K_TARGETS = "targets";

    private Config() {}

    public static final class Preset {
        public final String name;
        public final float pitch, barrel, size, loud, bass, boom, gate;

        Preset(String name, float pitch, float barrel, float size, float loud, float bass, float boom, float gate) {
            this.name = name;
            this.pitch = pitch;
            this.barrel = barrel;
            this.size = size;
            this.loud = loud;
            this.bass = bass;
            this.boom = boom;
            this.gate = gate;
        }
    }

    /** First preset must equal DspParams.DEFAULT (used when the hook cannot read the prefs). */
    public static final Preset[] PRESETS = {
            new Preset("Бочка", -3f, 1f, 0.65f, 12f, 6f, 0f, -48f),
            new Preset("ЗВУКОВОЙ БАРЬЕР", -5f, 1f, 0.9f, 48f, 15f, 1f, -40f),
            new Preset("Демон", -9f, 0.35f, 0.5f, 6f, 9f, 0f, -52f),
            new Preset("Бурундук", 7f, 0f, 0f, 0f, 0f, 0f, -70f),
            new Preset("Оригинал", 0f, 0f, 0f, 0f, 0f, 0f, -70f),
    };

    /** Opens the module prefs; world-readable where the framework allows it, private otherwise. */
    @SuppressWarnings("deprecation")
    @SuppressLint("WorldReadableFiles")
    public static SharedPreferences open(Context ctx) {
        try {
            return ctx.getSharedPreferences(PREFS, Context.MODE_WORLD_READABLE);
        } catch (SecurityException e) {
            return ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        }
    }

    public static boolean onlySelected(SharedPreferences sp) {
        return getBool(sp, K_ONLY, false);
    }

    /** Always returns a fresh copy (the set owned by SharedPreferences must never be modified). */
    public static Set<String> targets(SharedPreferences sp) {
        try {
            Set<String> s = sp.getStringSet(K_TARGETS, null);
            return s == null ? new HashSet<String>() : new HashSet<String>(s);
        } catch (ClassCastException e) {
            return new HashSet<String>();
        }
    }

    public static DspParams fromPrefs(SharedPreferences sp) {
        DspParams d = DspParams.DEFAULT;
        return new DspParams(
                getBool(sp, K_ENABLED, true),
                getFloat(sp, K_PITCH, d.pitchSemitones),
                getFloat(sp, K_BARREL, d.barrelMix),
                getFloat(sp, K_SIZE, d.barrelSize),
                getFloat(sp, K_LOUD, d.loudnessDb),
                getFloat(sp, K_BASS, d.bassDb),
                getFloat(sp, K_BOOM, d.boom),
                getFloat(sp, K_GATE, d.gateDb));
    }

    public static void ensureDefaults(SharedPreferences sp) {
        if (sp.contains(K_PITCH)) return;
        SharedPreferences.Editor e = sp.edit();
        e.putBoolean(K_ENABLED, true);
        put(e, PRESETS[0]);
        e.commit();
    }

    public static void put(SharedPreferences.Editor e, Preset p) {
        e.putFloat(K_PITCH, p.pitch);
        e.putFloat(K_BARREL, p.barrel);
        e.putFloat(K_SIZE, p.size);
        e.putFloat(K_LOUD, p.loud);
        e.putFloat(K_BASS, p.bass);
        e.putFloat(K_BOOM, p.boom);
        e.putFloat(K_GATE, p.gate);
    }

    private static boolean getBool(SharedPreferences sp, String k, boolean def) {
        try {
            return sp.getBoolean(k, def);
        } catch (ClassCastException e) {
            return def;
        }
    }

    private static float getFloat(SharedPreferences sp, String k, float def) {
        try {
            return sp.getFloat(k, def);
        } catch (ClassCastException e) {
            return def;
        }
    }
}
