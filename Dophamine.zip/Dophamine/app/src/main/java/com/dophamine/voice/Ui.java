package com.dophamine.voice;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.widget.Button;
import android.widget.TextView;

/** Colors and tiny view helpers shared by the secondary screens. */
final class Ui {
    static final int BG = 0xFF0E0F14;
    static final int CARD = 0xFF181A22;
    static final int CHIP = 0xFF262A36;
    static final int ACCENT = 0xFFFF6B3D;
    static final int TEXT = 0xFFECEEF4;
    static final int MUTED = 0xFF8B90A0;
    static final int GOOD = 0xFF4CD08B;
    static final int WARN = 0xFFFFB84D;
    static final int BAD = 0xFFFF5A5A;

    private Ui() {}

    static int dp(Context c, int v) {
        return (int) (v * c.getResources().getDisplayMetrics().density + 0.5f);
    }

    static GradientDrawable round(Context c, int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(c, radiusDp));
        return g;
    }

    static TextView text(Context c, String s, int sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    static Button button(Context c, String label, boolean selected) {
        Button b = new Button(c);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(14);
        b.setMinHeight(dp(c, 44));
        b.setBackground(round(c, selected ? ACCENT : CHIP, 12));
        b.setTextColor(selected ? Color.WHITE : TEXT);
        return b;
    }
}
