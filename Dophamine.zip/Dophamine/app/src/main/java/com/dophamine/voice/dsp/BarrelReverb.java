package com.dophamine.voice.dsp;

/**
 * "Sitting inside a barrel": the whole voice is band-limited and muffled, gets a
 * boxy resonance around 320 Hz, and a short metallic tube reverb made of four
 * damped feedback combs (3.9..9.7 ms, ~ a 1 m long hollow body) plus two
 * all-pass diffusers.
 */
final class BarrelReverb {
    private static final double[] COMB_MS = {3.9, 5.3, 7.1, 9.7};
    private static final double[] AP_MS = {5.0, 1.7};

    private static final class Comb {
        private final float[] buf;
        private int idx;
        private float store;
        private float fb = 0.7f;
        private float damp = 0.3f;

        Comb(int len) {
            buf = new float[len];
        }

        void set(float feedback, float damping) {
            fb = feedback;
            damp = damping;
        }

        void reset() {
            java.util.Arrays.fill(buf, 0f);
            idx = 0;
            store = 0f;
        }

        float process(float in) {
            float out = buf[idx];
            store = Dsp.flush(out * (1f - damp) + store * damp);
            buf[idx] = Dsp.flush(in + store * fb);
            if (++idx >= buf.length) idx = 0;
            return out * (1f - fb);
        }
    }

    private static final class Allpass {
        private final float[] buf;
        private int idx;

        Allpass(int len) {
            buf = new float[len];
        }

        void reset() {
            java.util.Arrays.fill(buf, 0f);
            idx = 0;
        }

        float process(float in) {
            float b = buf[idx];
            float out = b - in;
            buf[idx] = Dsp.flush(in + b * 0.5f);
            if (++idx >= buf.length) idx = 0;
            return out;
        }
    }

    private final int sr;
    private final Biquad hp = new Biquad();
    private final Biquad lp = new Biquad();
    private final Biquad peak = new Biquad();
    private final Comb[] combs = new Comb[COMB_MS.length];
    private final Allpass[] aps = new Allpass[AP_MS.length];
    private boolean active;
    private float wet;
    private float dry = 1f;

    BarrelReverb(int sr) {
        this.sr = sr;
        for (int i = 0; i < combs.length; i++) combs[i] = new Comb(Dsp.ms(sr, COMB_MS[i]));
        for (int i = 0; i < aps.length; i++) aps[i] = new Allpass(Dsp.ms(sr, AP_MS[i]));
    }

    void reset() {
        hp.reset();
        lp.reset();
        peak.reset();
        for (Comb c : combs) c.reset();
        for (Allpass a : aps) a.reset();
    }

    void configure(float mixIn, float sizeIn) {
        float mix = Dsp.clamp01(mixIn);
        float size = Dsp.clamp01(sizeIn);
        boolean was = active;
        active = mix >= 0.001f;
        if (!active) return;
        if (!was) reset();
        // 16 kHz (clean) -> 2.4 kHz (tin can) as the amount goes 0 -> 1
        double fc = 16000.0 * Math.pow(2400.0 / 16000.0, mix);
        lp.lowpass(sr, fc, 0.7);
        hp.highpass(sr, 90.0, 0.7);
        peak.peaking(sr, 320.0, 1.1, 7.0 * mix);
        float fb = 0.55f + 0.30f * size;
        float damp = 0.25f + 0.25f * size;
        for (Comb c : combs) c.set(fb, damp);
        wet = 0.65f * mix;
        dry = 1f - 0.3f * mix;
    }

    float process(float x) {
        if (!active) return x;
        float m = peak.process(lp.process(hp.process(x)));
        float sum = 0f;
        for (Comb c : combs) sum += c.process(m);
        sum *= 0.25f;
        for (Allpass a : aps) sum = a.process(sum);
        return m * dry + sum * wet;
    }
}
