package com.dophamine.voice;

import android.content.Context;
import android.content.Intent;
import android.media.AudioRecord;

import com.dophamine.voice.dsp.BufferProcessor;
import com.dophamine.voice.dsp.DspParams;
import com.dophamine.voice.dsp.ReentrancyGuard;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.nio.ByteBuffer;
import java.util.concurrent.atomic.AtomicBoolean;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XC_MethodReplacement;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage.LoadPackageParam;

/**
 * Dophamine: hooks every AudioRecord.read(...) overload of the selected apps and runs the
 * microphone audio through the DSP chain in place, after the framework filled the buffer.
 *
 * Logic guards:
 *  - hooked once per process (isFirstApplication + AtomicBoolean), otherwise callbacks stack up
 *    and audio would be processed twice;
 *  - nested read() overloads are processed only at the outermost level (ReentrancyGuard);
 *  - only [offset, offset + returned) is touched, errors/0 returns are ignored;
 *  - one DSP state per AudioRecord, reset on startRecording();
 *  - any exception inside our code is swallowed: the original audio must never break.
 */
public class DophamineHook implements IXposedHookLoadPackage {
    static final String SELF = "com.dophamine.voice";

    private static final int K_SHORTS = 1;
    private static final int K_BYTES = 2;
    private static final int K_FLOATS = 3;
    private static final int K_BUFFER = 4;

    private static final String EXTRA_OUTER = "dophamine.outer";

    private static final AtomicBoolean HOOKED = new AtomicBoolean(false);
    private static final ReentrancyGuard GUARD = new ReentrancyGuard();
    private static final BufferProcessor PROCESSOR = new BufferProcessor();
    private static volatile boolean errorLogged;
    /** Package of the process the hook lives in. */
    private static volatile String pkgName = "";

    @Override
    public void handleLoadPackage(LoadPackageParam lpparam) throws Throwable {
        if (SELF.equals(lpparam.packageName)) {
            hookSelf(lpparam);
            return;
        }
        if ("android".equals(lpparam.packageName) || !lpparam.isFirstApplication) return;
        if (!HOOKED.compareAndSet(false, true)) return;
        pkgName = lpparam.packageName;
        try {
            int n = hookAudioRecord();
            HookConfig.start();
            XposedBridge.log("Dophamine: hooked " + n + " AudioRecord.read overloads in " + lpparam.packageName);
        } catch (Throwable t) {
            HOOKED.set(false);
            XposedBridge.log("Dophamine: hook failed in " + lpparam.packageName + ": " + t);
        }
    }

    private static void hookSelf(LoadPackageParam lpparam) {
        try {
            XposedHelpers.findAndHookMethod(SELF + ".MainActivity", lpparam.classLoader,
                    "isModuleActive", XC_MethodReplacement.returnConstant(Boolean.TRUE));
        } catch (Throwable t) {
            XposedBridge.log("Dophamine: self hook failed: " + t);
        }
    }

    private static int hookAudioRecord() {
        int count = 0;
        for (Method m : AudioRecord.class.getDeclaredMethods()) {
            if (!Modifier.isPublic(m.getModifiers())) continue;
            String name = m.getName();
            if ("read".equals(name)) {
                int kind = classify(m.getParameterTypes());
                if (kind == 0) continue;
                XposedBridge.hookMethod(m, new ReadHook(kind));
                count++;
            } else if ("startRecording".equals(name)) {
                XposedBridge.hookMethod(m, new XC_MethodHook() {
                    @Override
                    protected void beforeHookedMethod(MethodHookParam param) {
                        PROCESSOR.markIdle(param.thisObject);
                        ping();
                    }
                });
            }
        }
        return count;
    }

    private static volatile long lastPing;

    /**
     * Best effort: tells the Dophamine app which app just started recording, so the settings
     * screen can show that the hook really is alive. Never throws, throttled to once per 10 s.
     */
    private static void ping() {
        long now = System.currentTimeMillis();
        if (now - lastPing < 10000L) return;
        lastPing = now;
        try {
            Object app = Class.forName("android.app.ActivityThread").getMethod("currentApplication").invoke(null);
            if (!(app instanceof Context)) return;
            Context c = (Context) app;
            Intent i = new Intent(Config.ACTION_HOOKED);
            i.setPackage(SELF);
            i.putExtra("pkg", c.getPackageName());
            i.putExtra("cfg", HookConfig.hasData());
            i.putExtra("allowed", HookConfig.allowed(c.getPackageName()));
            i.addFlags(Intent.FLAG_INCLUDE_STOPPED_PACKAGES);
            c.sendBroadcast(i);
        } catch (Throwable ignored) {
        }
    }

    private static int classify(Class<?>[] t) {
        if (t.length < 2 || t.length > 4) return 0;
        if (t[0] == short[].class && t.length >= 3 && t[1] == int.class && t[2] == int.class) return K_SHORTS;
        if (t[0] == byte[].class && t.length >= 3 && t[1] == int.class && t[2] == int.class) return K_BYTES;
        if (t[0] == float[].class && t.length >= 3 && t[1] == int.class && t[2] == int.class) return K_FLOATS;
        if (t[0] == ByteBuffer.class && t[1] == int.class) return K_BUFFER;
        return 0;
    }

    private static void logOnce(Throwable t) {
        if (errorLogged) return;
        errorLogged = true;
        XposedBridge.log("Dophamine: processing error (further errors muted): " + t);
    }

    private static final class ReadHook extends XC_MethodHook {
        private final int kind;

        ReadHook(int kind) {
            this.kind = kind;
        }

        @Override
        protected void beforeHookedMethod(MethodHookParam param) {
            boolean outer = GUARD.enter();
            param.setObjectExtra(EXTRA_OUTER, outer ? Boolean.TRUE : Boolean.FALSE);
        }

        @Override
        protected void afterHookedMethod(MethodHookParam param) {
            GUARD.exit();
            try {
                if (!Boolean.TRUE.equals(param.getObjectExtra(EXTRA_OUTER))) return;
                if (param.hasThrowable()) return;
                Object r = param.getResult();
                if (!(r instanceof Integer)) return;
                int n = ((Integer) r).intValue();
                if (n <= 0) return; // 0 = nothing read, negative = AudioRecord error code
                process(param, n);
            } catch (Throwable t) {
                logOnce(t);
            }
        }

        private void process(MethodHookParam param, int n) {
            AudioRecord rec = (AudioRecord) param.thisObject;
            DspParams p = HookConfig.current();
            if (!HookConfig.allowed(pkgName)) { // app is not in the target list
                PROCESSOR.markIdle(rec);
                return;
            }
            int sr = rec.getSampleRate();
            int ch = rec.getChannelCount();
            int enc = rec.getAudioFormat();
            Object[] a = param.args;
            switch (kind) {
                case K_SHORTS:
                    PROCESSOR.processShorts(rec, (short[]) a[0], (Integer) a[1], n, sr, ch, p);
                    break;
                case K_BYTES:
                    PROCESSOR.processBytes(rec, (byte[]) a[0], (Integer) a[1], n, enc, sr, ch, p);
                    break;
                case K_FLOATS:
                    PROCESSOR.processFloats(rec, (float[]) a[0], (Integer) a[1], n, sr, ch, p);
                    break;
                case K_BUFFER:
                    PROCESSOR.processByteBuffer(rec, (ByteBuffer) a[0], n, enc, sr, ch, p);
                    break;
                default:
                    break;
            }
        }
    }
}
