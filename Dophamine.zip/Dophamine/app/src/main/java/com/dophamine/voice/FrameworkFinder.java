package com.dophamine.voice;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.widget.Toast;

import java.util.List;
import java.util.Locale;

/** Finds and opens the LSPosed / Vector manager app. */
final class FrameworkFinder {
    private FrameworkFinder() {}

    private static boolean looksLikeManager(String pkgLower, String labelLower) {
        return pkgLower.contains("lsposed")
                || (pkgLower.contains("vector") && pkgLower.contains("manager"))
                || labelLower.contains("lsposed")
                || labelLower.equals("vector");
    }

    /** @return {label, version, package} or null. Cheap, safe on the UI thread. */
    static String[] byPackages(Context ctx) {
        try {
            PackageManager pm = ctx.getPackageManager();
            String self = ctx.getPackageName();
            List<ApplicationInfo> apps = pm.getInstalledApplications(0);
            for (ApplicationInfo ai : apps) {
                if (ai.packageName == null || ai.packageName.equals(self)) continue;
                String label = String.valueOf(pm.getApplicationLabel(ai));
                if (!looksLikeManager(ai.packageName.toLowerCase(Locale.ROOT), label.toLowerCase(Locale.ROOT))) continue;
                String version = "";
                try {
                    String v = pm.getPackageInfo(ai.packageName, 0).versionName;
                    if (v != null) version = v;
                } catch (Throwable ignored) {
                }
                return new String[]{label, version, ai.packageName};
            }
        } catch (Throwable ignored) {
        }
        return null;
    }

    /** Fallback when the system hides the app list from us. Blocking (su). */
    static String[] viaRoot(Context ctx) {
        String out = RootShell.run("pm list packages", 25);
        if (out == null) return null;
        for (String line : out.split("\n")) {
            String pkg = line.trim();
            if (pkg.startsWith("package:")) pkg = pkg.substring(8);
            if (pkg.length() == 0 || pkg.equals(ctx.getPackageName())) continue;
            if (looksLikeManager(pkg.toLowerCase(Locale.ROOT), "")) return new String[]{pkg, "", pkg};
        }
        return null;
    }

    /** Opens the manager: normal launch intent first, then LSPosed's root launch trick. */
    static void launch(final Activity a, String[] fw) {
        try {
            if (fw != null) {
                Intent i = a.getPackageManager().getLaunchIntentForPackage(fw[2]);
                if (i != null) {
                    a.startActivity(i);
                    return;
                }
            }
        } catch (Throwable ignored) {
        }
        new Thread(new Runnable() {
            @Override
            public void run() {
                final String r = RootShell.run(
                        "am start -c org.lsposed.manager.LAUNCH_MANAGER com.android.shell/.BugreportWarningActivity", 15);
                a.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(a, r != null ? "Открываю менеджер через root…"
                                : "Не получилось. Открой менеджер из уведомления LSPosed/Vector или через Magisk / KernelSU.",
                                Toast.LENGTH_LONG).show();
                    }
                });
            }
        }, "dophamine-launch").start();
    }
}
