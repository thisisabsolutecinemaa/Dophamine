package com.dophamine.voice.check;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Locale;

/** Strict, layered verdict "is LSPosed / Vector really working with this module". */
public final class FrameworkCheck {
    public enum State { ACTIVE, NEEDS_SETUP, NOT_FOUND, API_BUNDLED }

    /** A hook ping younger than this counts as proof that the hook is alive. */
    public static final long PING_FRESH_MS = 15L * 60L * 1000L;

    private static final String[] TOKENS = {"lspd", "lsposed", "xposed", "riru", "zygisk", "/data/adb/modules"};

    private FrameworkCheck() {}

    /**
     * @param pingAgeMs age of the last "hook started recording" ping, or -1 if there never was one
     */
    public static State verdict(boolean apiBundled, boolean managerFound, boolean traces,
                                boolean moduleLoaded, long pingAgeMs) {
        if (apiBundled) return State.API_BUNDLED;
        if (moduleLoaded || (pingAgeMs >= 0L && pingAgeMs <= PING_FRESH_MS)) return State.ACTIVE;
        if (managerFound || traces) return State.NEEDS_SETUP;
        return State.NOT_FOUND;
    }

    /** One line of /proc/self/maps: does it look like a Zygisk / Riru / LSPosed / Vector mapping? */
    public static boolean isInjectionTrace(String line) {
        if (line == null) return false;
        String s = line.toLowerCase(Locale.ROOT);
        for (String t : TOKENS) if (s.contains(t)) return true;
        return s.contains("vector") && s.contains("/data/adb");
    }

    /** Heuristic: injection frameworks are mapped into app processes (they may hide this). */
    public static boolean hasInjectionTraces() {
        BufferedReader r = null;
        try {
            r = new BufferedReader(new FileReader("/proc/self/maps"));
            String line;
            int n = 0;
            while ((line = r.readLine()) != null && n++ < 60000) {
                if (isInjectionTrace(line)) return true;
            }
        } catch (Throwable ignored) {
        } finally {
            if (r != null) {
                try {
                    r.close();
                } catch (Throwable ignored) {
                }
            }
        }
        return false;
    }
}
