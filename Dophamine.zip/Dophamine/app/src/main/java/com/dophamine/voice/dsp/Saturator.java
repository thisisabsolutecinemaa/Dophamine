package com.dophamine.voice.dsp;

/**
 * Final soft limiter. Transparent up to 0.8 FS, then a smooth tanh-like knee
 * that approaches (but never exceeds) 1.0. With huge gain in front of it the
 * result is the classic "speaker is dying" wall of clipping.
 */
final class Saturator {
    private static final float KNEE = 0.8f;
    private static final float RANGE = 0.2f;

    private Saturator() {}

    static float soft(float v) {
        float a = v < 0f ? -v : v;
        if (a <= KNEE) return v;
        float x = (a - KNEE) * (1f / RANGE);
        // rational tanh approximation, exact 1.0 with zero slope at x = 3
        float t = x >= 3f ? 1f : x * (27f + x * x) / (27f + 9f * x * x);
        float y = KNEE + RANGE * t;
        return v < 0f ? -y : y;
    }
}
