package com.dophamine.voice.check;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * Detects the classic module mistake: Xposed API classes compiled INTO the module's APK.
 * Vector / LSPosed refuse such a module ("Cannot load module"). A class that is merely
 * referenced (as every module does) is not a problem, only a class that is DEFINED in the dex.
 */
public final class DexProbe {
    public static final String XPOSED_PREFIX = "Lde/robv/android/xposed/";
    private static final int MAX_DEX = 64 * 1024 * 1024;
    private static final int MAX_CLASSES = 400000;

    private DexProbe() {}

    /** @return 1 = the APK defines Xposed API classes, 0 = it does not, -1 = APK could not be read. */
    public static int apkDefinesXposedApi(String apkPath) {
        ZipFile zip = null;
        try {
            zip = new ZipFile(apkPath);
            boolean sawDex = false;
            Enumeration<? extends ZipEntry> en = zip.entries();
            while (en.hasMoreElements()) {
                ZipEntry e = en.nextElement();
                if (!e.getName().matches("classes[0-9]*\\.dex")) continue;
                sawDex = true;
                byte[] d = readAll(zip.getInputStream(e));
                if (d == null) return -1;
                if (definesClassWithPrefix(d, XPOSED_PREFIX)) return 1;
            }
            return sawDex ? 0 : -1;
        } catch (Throwable t) {
            return -1;
        } finally {
            if (zip != null) {
                try {
                    zip.close();
                } catch (Throwable ignored) {
                }
            }
        }
    }

    private static byte[] readAll(InputStream in) throws Exception {
        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) > 0) {
                out.write(buf, 0, n);
                if (out.size() > MAX_DEX) return null;
            }
            return out.toByteArray();
        } finally {
            in.close();
        }
    }

    /** Walks the DEX class_defs table; never throws, malformed data simply gives false. */
    public static boolean definesClassWithPrefix(byte[] d, String prefix) {
        try {
            if (d == null || d.length < 0x70) return false;
            if (d[0] != 'd' || d[1] != 'e' || d[2] != 'x' || d[3] != '\n') return false;
            int strIdsSize = u32(d, 0x38);
            int strIdsOff = u32(d, 0x3C);
            int typeIdsSize = u32(d, 0x40);
            int typeIdsOff = u32(d, 0x44);
            int classDefsSize = Math.min(u32(d, 0x60), MAX_CLASSES);
            int classDefsOff = u32(d, 0x64);
            byte[] want = prefix.getBytes("UTF-8");
            for (int i = 0; i < classDefsSize; i++) {
                int classIdx = u32(d, classDefsOff + i * 32);
                if (classIdx < 0 || classIdx >= typeIdsSize) continue;
                int descIdx = u32(d, typeIdsOff + classIdx * 4);
                if (descIdx < 0 || descIdx >= strIdsSize) continue;
                int p = u32(d, strIdsOff + descIdx * 4);
                while ((d[p] & 0x80) != 0) p++; // skip the uleb128 length
                p++;
                if (startsWith(d, p, want)) return true;
            }
        } catch (Exception e) {
            // truncated / garbage dex
        }
        return false;
    }

    private static boolean startsWith(byte[] d, int p, byte[] want) {
        if (p < 0 || p + want.length > d.length) return false;
        for (int i = 0; i < want.length; i++) if (d[p + i] != want[i]) return false;
        return true;
    }

    private static int u32(byte[] d, int o) {
        return (d[o] & 0xFF) | ((d[o + 1] & 0xFF) << 8) | ((d[o + 2] & 0xFF) << 16) | ((d[o + 3] & 0xFF) << 24);
    }
}
