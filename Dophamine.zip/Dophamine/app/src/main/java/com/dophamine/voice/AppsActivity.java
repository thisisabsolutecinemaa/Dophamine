package com.dophamine.voice;

import android.app.Activity;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.LruCache;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Target apps: every installed app with a checkbox. The voice is changed only in the checked apps
 * when "only selected" is on. LSPosed's own scope still decides where the module is loaded at all.
 */
public class AppsActivity extends Activity {
    /** Popular voice-chat apps, shown first. */
    private static final String[] KNOWN = {
            "org.telegram.messenger", "org.telegram.messenger.web", "org.thunderdog.challegram",
            "com.discord", "com.whatsapp", "com.whatsapp.w4b", "com.viber.voip", "us.zoom.videomeetings",
            "com.skype.raider", "org.thoughtcrime.securesms", "com.vkontakte.android", "com.snapchat.android",
            "com.instagram.android", "com.facebook.orca", "com.tencent.mm", "jp.naver.line.android",
            "com.google.android.apps.tachyon", "com.zhiliaoapp.musically"};

    private static final class Item {
        String label;
        String pkg;
        boolean system;
        boolean known;
    }

    private SharedPreferences prefs;
    private final List<Item> all = new ArrayList<Item>();
    private final List<Item> shown = new ArrayList<Item>();
    private final Set<String> selected = new HashSet<String>();
    private final LruCache<String, Drawable> icons = new LruCache<String, Drawable>(150);
    private boolean showSystem;
    private boolean onlyChecked;
    private Set<String> lspScope; // apps in the module scope per LSPosed, null = unknown
    private String query = "";

    private Adapter adapter;
    private TextView countView;
    private TextView hintView;
    private Switch onlySwitch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = Config.open(this);
        selected.addAll(Config.targets(prefs));
        setContentView(buildUi());
        load();
        loadScope();
    }

    private int dp(int v) {
        return Ui.dp(this, v);
    }

    private void saveTargets() {
        prefs.edit().putStringSet(Config.K_TARGETS, new HashSet<String>(selected)).apply();
    }

    // ------------------------------------------------------------------ UI

    private View buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.BG);
        root.setPadding(dp(16), dp(28), dp(16), dp(8));

        root.addView(Ui.text(this, "Целевые приложения", 24, Ui.ACCENT, true));
        root.addView(Ui.text(this, "Где менять голос. Приложение должно быть ещё и в области действия модуля в LSPosed / Vector.",
                12, Ui.MUTED, false));

        onlySwitch = new Switch(this);
        onlySwitch.setText("Менять звук только в выбранных");
        onlySwitch.setTextColor(Ui.TEXT);
        onlySwitch.setTextSize(15);
        onlySwitch.setChecked(Config.onlySelected(prefs));
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        slp.topMargin = dp(14);
        onlySwitch.setLayoutParams(slp);
        onlySwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton b, boolean checked) {
                prefs.edit().putBoolean(Config.K_ONLY, checked).apply();
                updateCount();
            }
        });
        root.addView(onlySwitch);

        hintView = Ui.text(this, "", 12, Ui.MUTED, false);
        hintView.setPadding(0, dp(4), 0, dp(8));
        root.addView(hintView);

        EditText search = new EditText(this);
        search.setHint("Поиск по названию или пакету");
        search.setHintTextColor(Ui.MUTED);
        search.setTextColor(Ui.TEXT);
        search.setTextSize(14);
        search.setSingleLine(true);
        search.setPadding(dp(14), dp(10), dp(14), dp(10));
        search.setBackground(Ui.round(this, Ui.CARD, 12));
        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {
            }

            @Override
            public void onTextChanged(CharSequence s, int a, int b, int c) {
                query = s.toString().trim().toLowerCase(Locale.ROOT);
                applyFilter();
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
        root.addView(search);

        LinearLayout toggles = new LinearLayout(this);
        toggles.setOrientation(LinearLayout.HORIZONTAL);
        toggles.setPadding(0, dp(8), 0, 0);
        Switch sys = new Switch(this);
        sys.setText("Системные ");
        sys.setTextColor(Ui.TEXT);
        sys.setTextSize(13);
        sys.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton b, boolean checked) {
                showSystem = checked;
                applyFilter();
            }
        });
        Switch chk = new Switch(this);
        chk.setText("Только отмеченные ");
        chk.setTextColor(Ui.TEXT);
        chk.setTextSize(13);
        chk.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton b, boolean checked) {
                onlyChecked = checked;
                applyFilter();
            }
        });
        LinearLayout.LayoutParams half = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        sys.setLayoutParams(half);
        chk.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        toggles.addView(sys);
        toggles.addView(chk);
        root.addView(toggles);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setPadding(0, dp(8), 0, dp(4));
        Button selAll = Ui.button(this, "Отметить показанные", false);
        selAll.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        selAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                for (Item it : shown) selected.add(it.pkg);
                saveTargets();
                applyFilter();
            }
        });
        Button clear = Ui.button(this, "Снять все", false);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        clp.leftMargin = dp(8);
        clear.setLayoutParams(clp);
        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selected.clear();
                saveTargets();
                applyFilter();
            }
        });
        actions.addView(selAll);
        actions.addView(clear);
        root.addView(actions);

        Button openMgr = Ui.button(this, "Открыть LSPosed / Vector", false);
        openMgr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FrameworkFinder.launch(AppsActivity.this, FrameworkFinder.byPackages(AppsActivity.this));
            }
        });
        root.addView(openMgr);

        countView = Ui.text(this, "Загружаю список…", 12, Ui.MUTED, false);
        countView.setPadding(0, dp(4), 0, dp(6));
        root.addView(countView);

        ListView list = new ListView(this);
        list.setDivider(null);
        adapter = new Adapter();
        list.setAdapter(adapter);
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position < 0 || position >= shown.size()) return;
                String pkg = shown.get(position).pkg;
                if (!selected.remove(pkg)) {
                    selected.add(pkg);
                    if (lspScope != null && !lspScope.contains(pkg)) {
                        Toast.makeText(AppsActivity.this, "Нет в области LSPosed: звук там не изменится. "
                                + "Добавь приложение в Модули → Dophamine.", Toast.LENGTH_LONG).show();
                    }
                }
                saveTargets();
                if (onlyChecked) applyFilter();
                else {
                    adapter.notifyDataSetChanged();
                    updateCount();
                }
            }
        });
        root.addView(list, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        return root;
    }

    // ------------------------------------------------------------------ data

    private void load() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                final List<Item> items = new ArrayList<Item>();
                try {
                    PackageManager pm = getPackageManager();
                    Set<String> known = new HashSet<String>();
                    Collections.addAll(known, KNOWN);
                    for (ApplicationInfo ai : pm.getInstalledApplications(0)) {
                        if (ai.packageName == null || ai.packageName.equals(getPackageName())) continue;
                        Item it = new Item();
                        it.pkg = ai.packageName;
                        it.label = String.valueOf(pm.getApplicationLabel(ai));
                        it.system = (ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0
                                && (ai.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0;
                        it.known = known.contains(it.pkg);
                        items.add(it);
                    }
                } catch (Throwable ignored) {
                }
                Collections.sort(items, new Comparator<Item>() {
                    @Override
                    public int compare(Item a, Item b) {
                        if (a.known != b.known) return a.known ? -1 : 1;
                        return a.label.compareToIgnoreCase(b.label);
                    }
                });
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        all.clear();
                        all.addAll(items);
                        applyFilter();
                    }
                });
            }
        }, "dophamine-apps").start();
    }

    /** Asks LSPosed (via root) which apps are in the module scope, then marks them in the list. */
    private void loadScope() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                final LspScope.Result r = LspScope.query(AppsActivity.this, getPackageName());
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (r.dbOk && r.moduleFound) {
                            lspScope = r.scope;
                            adapter.notifyDataSetChanged();
                        }
                    }
                });
            }
        }, "dophamine-scope").start();
    }

    private void applyFilter() {
        shown.clear();
        for (Item it : all) {
            boolean sel = selected.contains(it.pkg);
            if (!showSystem && it.system && !sel) continue;
            if (onlyChecked && !sel) continue;
            if (query.length() > 0 && !it.label.toLowerCase(Locale.ROOT).contains(query)
                    && !it.pkg.toLowerCase(Locale.ROOT).contains(query)) continue;
            shown.add(it);
        }
        adapter.notifyDataSetChanged();
        updateCount();
    }

    private void updateCount() {
        countView.setText("Отмечено: " + selected.size() + " · показано: " + shown.size() + " из " + all.size());
        if (onlySwitch.isChecked() && selected.isEmpty()) {
            hintView.setText("Список пуст: пока ничего не отмечено, звук не будет меняться нигде.");
            hintView.setTextColor(Ui.BAD);
        } else if (onlySwitch.isChecked()) {
            hintView.setText("Звук меняется только в отмеченных приложениях.");
            hintView.setTextColor(Ui.GOOD);
        } else {
            hintView.setText("Выключено: звук меняется во всех приложениях из области действия LSPosed.");
            hintView.setTextColor(Ui.MUTED);
        }
    }

    // ------------------------------------------------------------------ list

    private final class Holder {
        ImageView icon;
        TextView label;
        TextView pkg;
        CheckBox check;
    }

    private final class Adapter extends BaseAdapter {
        @Override
        public int getCount() {
            return shown.size();
        }

        @Override
        public Object getItem(int position) {
            return shown.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            Holder h;
            View row = convertView;
            if (row == null) {
                LinearLayout r = new LinearLayout(AppsActivity.this);
                r.setOrientation(LinearLayout.HORIZONTAL);
                r.setPadding(dp(8), dp(8), dp(8), dp(8));
                r.setGravity(android.view.Gravity.CENTER_VERTICAL);
                h = new Holder();
                h.icon = new ImageView(AppsActivity.this);
                h.icon.setLayoutParams(new LinearLayout.LayoutParams(dp(40), dp(40)));
                LinearLayout col = new LinearLayout(AppsActivity.this);
                col.setOrientation(LinearLayout.VERTICAL);
                LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
                clp.leftMargin = dp(12);
                col.setLayoutParams(clp);
                h.label = Ui.text(AppsActivity.this, "", 15, Ui.TEXT, false);
                h.label.setSingleLine(true);
                h.pkg = Ui.text(AppsActivity.this, "", 11, Ui.MUTED, false);
                h.pkg.setSingleLine(true);
                col.addView(h.label);
                col.addView(h.pkg);
                h.check = new CheckBox(AppsActivity.this);
                h.check.setClickable(false);
                h.check.setFocusable(false);
                r.addView(h.icon);
                r.addView(col);
                r.addView(h.check);
                r.setTag(h);
                row = r;
            } else {
                h = (Holder) row.getTag();
            }
            Item it = shown.get(position);
            h.label.setText(it.known ? "★ " + it.label : it.label);
            if (lspScope == null) {
                h.pkg.setText(it.pkg);
                h.pkg.setTextColor(Ui.MUTED);
            } else if (lspScope.contains(it.pkg)) {
                h.pkg.setText(it.pkg + "  ✓ в области LSPosed");
                h.pkg.setTextColor(Ui.GOOD);
            } else {
                h.pkg.setText(it.pkg + "  ✗ не в области");
                h.pkg.setTextColor(Ui.BAD);
            }
            h.check.setChecked(selected.contains(it.pkg));
            row.setBackground(Ui.round(AppsActivity.this, selected.contains(it.pkg) ? Ui.CHIP : Ui.BG, 10));
            Drawable d = icons.get(it.pkg);
            if (d == null) {
                try {
                    d = getPackageManager().getApplicationIcon(it.pkg);
                    icons.put(it.pkg, d);
                } catch (Throwable ignored) {
                }
            }
            h.icon.setImageDrawable(d);
            return row;
        }
    }
}
