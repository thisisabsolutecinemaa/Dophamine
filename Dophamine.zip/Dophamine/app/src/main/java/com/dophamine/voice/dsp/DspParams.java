package com.dophamine.voice.dsp;

/** Immutable, always-sanitised effect settings (NaN / out-of-range values can't get in). */
public final class DspParams {
    public static final float PITCH_MIN = -12f;
    public static final float PITCH_MAX = 12f;
    public static final float LOUD_MAX = 60f;
    public static final float BASS_MAX = 18f;
    public static final float GATE_MIN = -70f;
    public static final float GATE_MAX = -20f;
    /** Anything at or below this means "gate off". */
    public static final float GATE_OFF_DB = -69.5f;

    public static final DspParams DEFAULT =
            new DspParams(true, -3f, 1f, 0.65f, 12f, 6f, 0f, -48f);

    public final boolean enabled;
    public final float pitchSemitones;
    public final float barrelMix;
    public final float barrelSize;
    public final float loudnessDb;
    public final float bassDb;
    public final float boom;
    public final float gateDb;

    public DspParams(boolean enabled, float pitchSemitones, float barrelMix, float barrelSize,
                     float loudnessDb, float bassDb, float boom, float gateDb) {
        this.enabled = enabled;
        this.pitchSemitones = clamp(pitchSemitones, PITCH_MIN, PITCH_MAX, 0f);
        this.barrelMix = clamp(barrelMix, 0f, 1f, 0f);
        this.barrelSize = clamp(barrelSize, 0f, 1f, 0.5f);
        this.loudnessDb = clamp(loudnessDb, 0f, LOUD_MAX, 0f);
        this.bassDb = clamp(bassDb, 0f, BASS_MAX, 0f);
        this.boom = clamp(boom, 0f, 1f, 0f);
        this.gateDb = clamp(gateDb, GATE_MIN, GATE_MAX, GATE_MIN);
    }

    static float clamp(float v, float lo, float hi, float def) {
        if (v != v) return def;
        return v < lo ? lo : (v > hi ? hi : v);
    }

    public boolean gateOn() {
        return gateDb > GATE_OFF_DB;
    }

    /** True when processing would be a no-op, so audio must pass through bit-exact. */
    public boolean isNeutral() {
        return Math.abs(pitchSemitones) < 0.02f
                && barrelMix < 0.001f
                && loudnessDb < 0.05f
                && bassDb < 0.05f
                && boom < 0.001f
                && !gateOn();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof DspParams)) return false;
        DspParams p = (DspParams) o;
        return enabled == p.enabled
                && Float.compare(pitchSemitones, p.pitchSemitones) == 0
                && Float.compare(barrelMix, p.barrelMix) == 0
                && Float.compare(barrelSize, p.barrelSize) == 0
                && Float.compare(loudnessDb, p.loudnessDb) == 0
                && Float.compare(bassDb, p.bassDb) == 0
                && Float.compare(boom, p.boom) == 0
                && Float.compare(gateDb, p.gateDb) == 0;
    }

    @Override
    public int hashCode() {
        int h = enabled ? 1 : 0;
        h = 31 * h + Float.floatToIntBits(pitchSemitones);
        h = 31 * h + Float.floatToIntBits(barrelMix);
        h = 31 * h + Float.floatToIntBits(barrelSize);
        h = 31 * h + Float.floatToIntBits(loudnessDb);
        h = 31 * h + Float.floatToIntBits(bassDb);
        h = 31 * h + Float.floatToIntBits(boom);
        h = 31 * h + Float.floatToIntBits(gateDb);
        return h;
    }
}
