package com.dophamine.voice.dsp;

/**
 * AudioRecord.read(x, off, size) calls read(x, off, size, READ_BLOCKING) on API 23+,
 * and read(ByteBuffer, size) calls the 3-arg overload. If every overload is hooked the
 * same audio would be processed once per nesting level (double pitch shift, double
 * boom...). Only the outermost call on a thread may process the buffer.
 */
public final class ReentrancyGuard {
    private static final int MAX_DEPTH = 16;

    private final ThreadLocal<int[]> depth = new ThreadLocal<int[]>() {
        @Override
        protected int[] initialValue() {
            return new int[1];
        }
    };

    /** @return true if this call is the outermost one on the current thread. */
    public boolean enter() {
        int[] d = depth.get();
        if (d[0] < 0 || d[0] > MAX_DEPTH) d[0] = 0; // self-heal if an exit() was ever lost
        return d[0]++ == 0;
    }

    public void exit() {
        int[] d = depth.get();
        if (d[0] > 0) d[0]--;
    }
}
