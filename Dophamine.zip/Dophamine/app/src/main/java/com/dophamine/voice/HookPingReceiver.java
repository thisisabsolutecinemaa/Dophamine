package com.dophamine.voice;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Receives "app X started recording through the hook" and remembers it for the status card. */
public class HookPingReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (context == null || intent == null || !Config.ACTION_HOOKED.equals(intent.getAction())) return;
        String pkg = intent.getStringExtra("pkg");
        if (pkg == null || pkg.length() == 0 || pkg.length() > 200) return;
        context.getSharedPreferences(Config.STATE_PREFS, Context.MODE_PRIVATE).edit()
                .putString(Config.ST_LAST_PKG, pkg)
                .putLong(Config.ST_LAST_TIME, System.currentTimeMillis())
                .putBoolean(Config.ST_LAST_CFG, intent.getBooleanExtra("cfg", false))
                .putBoolean(Config.ST_LAST_ALLOWED, intent.getBooleanExtra("allowed", true))
                .apply();
    }
}
