package com.dophamine.voice.dsp;

/** RBJ-cookbook biquad, transposed direct form II, double-precision state. */
final class Biquad {
    private double b0 = 1.0, b1, b2, a1, a2;
    private double z1, z2;

    void reset() {
        z1 = 0.0;
        z2 = 0.0;
    }

    float process(float x) {
        double y = b0 * x + z1;
        z1 = b1 * x - a1 * y + z2;
        z2 = b2 * x - a2 * y;
        if (z1 < 1e-25 && z1 > -1e-25) z1 = 0.0;
        if (z2 < 1e-25 && z2 > -1e-25) z2 = 0.0;
        return (float) y;
    }

    private void set(double nb0, double nb1, double nb2, double na0, double na1, double na2) {
        double inv = 1.0 / na0;
        b0 = nb0 * inv;
        b1 = nb1 * inv;
        b2 = nb2 * inv;
        a1 = na1 * inv;
        a2 = na2 * inv;
    }

    private static double freq(double sr, double f) {
        return Math.max(10.0, Math.min(f, sr * 0.45));
    }

    void lowpass(double sr, double f, double q) {
        double w0 = 2.0 * Math.PI * freq(sr, f) / sr;
        double c = Math.cos(w0);
        double alpha = Math.sin(w0) / (2.0 * q);
        set((1.0 - c) / 2.0, 1.0 - c, (1.0 - c) / 2.0, 1.0 + alpha, -2.0 * c, 1.0 - alpha);
    }

    void highpass(double sr, double f, double q) {
        double w0 = 2.0 * Math.PI * freq(sr, f) / sr;
        double c = Math.cos(w0);
        double alpha = Math.sin(w0) / (2.0 * q);
        set((1.0 + c) / 2.0, -(1.0 + c), (1.0 + c) / 2.0, 1.0 + alpha, -2.0 * c, 1.0 - alpha);
    }

    void peaking(double sr, double f, double q, double gainDb) {
        double a = Math.pow(10.0, gainDb / 40.0);
        double w0 = 2.0 * Math.PI * freq(sr, f) / sr;
        double c = Math.cos(w0);
        double alpha = Math.sin(w0) / (2.0 * q);
        set(1.0 + alpha * a, -2.0 * c, 1.0 - alpha * a, 1.0 + alpha / a, -2.0 * c, 1.0 - alpha / a);
    }

    void lowShelf(double sr, double f, double gainDb) {
        double a = Math.pow(10.0, gainDb / 40.0);
        double w0 = 2.0 * Math.PI * freq(sr, f) / sr;
        double c = Math.cos(w0);
        double alpha = Math.sin(w0) / 2.0 * Math.sqrt(2.0);
        double beta = 2.0 * Math.sqrt(a) * alpha;
        set(a * ((a + 1.0) - (a - 1.0) * c + beta),
            2.0 * a * ((a - 1.0) - (a + 1.0) * c),
            a * ((a + 1.0) - (a - 1.0) * c - beta),
            (a + 1.0) + (a - 1.0) * c + beta,
            -2.0 * ((a - 1.0) + (a + 1.0) * c),
            (a + 1.0) + (a - 1.0) * c - beta);
    }
}
