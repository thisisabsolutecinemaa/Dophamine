package com.dophamine.voice.dsp;

/**
 * "Sonic boom": every time the voice starts after a pause, a sub-bass sine
 * (130 Hz sliding down to 38 Hz, ~200 ms decay) is fired. Trigger is armed only
 * after the level fell well below the threshold, so a sustained sound produces
 * one boom and not a machine gun.
 */
final class BoomThump {
    private static final float THRESHOLD = 0.04f;
    private static final float F_START = 130f;
    private static final float F_END = 38f;
    private static final double TWO_PI = Math.PI * 2.0;

    private final float atk;
    private final float rel;
    private final float freqDecay;
    private final float ampDecay;
    private final double phaseStep;

    private float env;
    private boolean armed = true;
    private float amp;
    private float freq = F_END;
    private double phase;

    BoomThump(int sr) {
        atk = Dsp.coef(sr, 0.002);
        rel = Dsp.coef(sr, 0.060);
        freqDecay = (float) Math.exp(-1.0 / (0.12 * sr));
        ampDecay = (float) Math.exp(-1.0 / (0.20 * sr));
        phaseStep = TWO_PI / sr;
    }

    void reset() {
        env = 0f;
        armed = true;
        amp = 0f;
        phase = 0.0;
        freq = F_END;
    }

    /** @param x the (gated) input sample used to detect voice onsets. */
    float process(float x) {
        float a = x < 0f ? -x : x;
        env += (a - env) * (a > env ? atk : rel);
        if (armed) {
            if (env > THRESHOLD) {
                armed = false;
                amp = 1f;
                phase = 0.0;
                freq = F_START;
            }
        } else if (env < THRESHOLD * 0.4f) {
            armed = true;
        }
        if (amp < 1e-4f) {
            amp = 0f;
            return 0f;
        }
        float out = (float) Math.sin(phase) * amp;
        phase += phaseStep * freq;
        if (phase >= TWO_PI) phase -= TWO_PI;
        freq = F_END + (freq - F_END) * freqDecay;
        amp *= ampDecay;
        return out;
    }
}
