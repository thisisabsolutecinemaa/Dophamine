package com.dophamine.voice.dsp;

import java.util.Arrays;

/**
 * Streaming pitch shifter: two delay-line read heads sweep through a circular
 * buffer and are cross-faded with an equal-power window. Low latency (about
 * half the window, ~22 ms), no FFT, constant output length, fully per-sample
 * so chunk size never changes the result.
 */
final class PitchShifter {
    private static final double WINDOW_SEC = 0.045;

    private final float[] buf;
    private final int mask;
    private final double win;
    private int w;
    private double d;      // delay of head 1 in samples, [0, win)
    private double step;   // 1 - ratio

    PitchShifter(int sr) {
        int winSamples = Math.max(64, (int) Math.round(sr * WINDOW_SEC));
        win = winSamples;
        int size = 128;
        while (size < winSamples + 4) size <<= 1;
        buf = new float[size];
        mask = size - 1;
    }

    void setSemitones(float semitones) {
        step = 1.0 - Math.pow(2.0, semitones / 12.0);
    }

    void reset() {
        Arrays.fill(buf, 0f);
        w = 0;
        d = 0.0;
    }

    float process(float x) {
        buf[w] = x;
        double d1 = d;
        double d2 = d + win * 0.5;
        if (d2 >= win) d2 -= win;
        double s = Math.sin(Math.PI * d1 / win);          // head 1 gain, 0 at the wrap point
        double g2 = Math.sqrt(Math.max(0.0, 1.0 - s * s)); // head 2 gain (equal power)
        double y = s * tap(d1) + g2 * tap(d2);
        d += step;
        if (d >= win) d -= win;
        else if (d < 0.0) d += win;
        w = (w + 1) & mask;
        return (float) y;
    }

    private double tap(double delay) {
        double pos = w - delay;
        int i0 = (int) Math.floor(pos);
        double frac = pos - i0;
        double a = buf[i0 & mask];
        double b = buf[(i0 + 1) & mask];
        return a + (b - a) * frac;
    }
}
