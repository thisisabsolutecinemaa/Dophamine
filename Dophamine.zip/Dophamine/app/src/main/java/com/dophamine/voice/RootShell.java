package com.dophamine.voice;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.concurrent.TimeUnit;

/** Runs one command through su. Blocking: never call it on the UI thread. */
final class RootShell {
    private RootShell() {}

    /** @return the command output, or null if root is missing, denied or the command timed out. */
    static String run(String cmd, long timeoutSec) {
        Process p = null;
        try {
            p = new ProcessBuilder("su", "-c", cmd).redirectErrorStream(true).start();
            final Process proc = p;
            final StringBuilder sb = new StringBuilder();
            Thread reader = new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        BufferedReader r = new BufferedReader(new InputStreamReader(proc.getInputStream()));
                        String line;
                        while ((line = r.readLine()) != null) {
                            synchronized (sb) {
                                sb.append(line).append('\n');
                            }
                        }
                    } catch (Throwable ignored) {
                    }
                }
            }, "dophamine-su-reader");
            reader.setDaemon(true);
            reader.start();
            if (!p.waitFor(timeoutSec, TimeUnit.SECONDS)) {
                p.destroy();
                return null;
            }
            reader.join(1500);
            String out;
            synchronized (sb) {
                out = sb.toString();
            }
            if (p.exitValue() != 0 && out.trim().length() == 0) return null;
            return out;
        } catch (Throwable t) {
            if (p != null) p.destroy();
            return null;
        }
    }
}
