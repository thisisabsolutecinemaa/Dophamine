package com.dophamine.voice.dsp;

import java.nio.ByteBuffer;
import java.util.Random;

/**
 * Logic self-test for the whole DSP path. Runs on a desktop JVM
 * (java com.dophamine.voice.dsp.DspSelfTest) and inside the app (button "Самотест").
 */
public final class DspSelfTest {

    public static final class Result {
        public final boolean ok;
        public final String text;

        Result(boolean ok, String text) {
            this.ok = ok;
            this.text = text;
        }
    }

    public static Result run(boolean quick) {
        DspSelfTest t = new DspSelfTest(quick);
        t.all();
        return new Result(t.failed == 0, t.report());
    }

    public static void main(String[] args) {
        Result r = run(args.length > 0 && "quick".equals(args[0]));
        System.out.println(r.text);
        System.exit(r.ok ? 0 : 1);
    }

    // ------------------------------------------------------------------ harness

    private final boolean quick;
    private int passed;
    private int failed;
    private final StringBuilder log = new StringBuilder();

    private DspSelfTest(boolean quick) {
        this.quick = quick;
    }

    private String report() {
        log.append("\nИТОГО: ").append(passed).append(" ok, ").append(failed).append(" fail\n");
        return log.toString();
    }

    private void check(String name, boolean cond, String detail) {
        if (cond) passed++;
        else failed++;
        log.append(cond ? "[ok]   " : "[FAIL] ").append(name);
        if (detail != null && detail.length() > 0) log.append("  (").append(detail).append(")");
        log.append('\n');
    }

    private interface Body {
        void run() throws Exception;
    }

    private void guard(String name, Body b) {
        try {
            b.run();
        } catch (Throwable t) {
            check(name, false, "исключение: " + t);
        }
    }

    private void all() {
        guard("params", new Body() { public void run() { testParams(); } });
        guard("pitch", new Body() { public void run() { testPitch(); } });
        guard("chunks", new Body() { public void run() { testChunkInvariance(); } });
        guard("stereo", new Body() { public void run() { testStereo(); } });
        guard("stress", new Body() { public void run() { testStress(); } });
        guard("silence", new Body() { public void run() { testSilence(); } });
        guard("gate", new Body() { public void run() { testGate(); } });
        guard("loudness", new Body() { public void run() { testLoudness(); } });
        guard("barrel", new Body() { public void run() { testBarrel(); } });
        guard("boom", new Body() { public void run() { testBoom(); } });
        guard("tail", new Body() { public void run() { testTailDies(); } });
        guard("pitch-toggle", new Body() { public void run() { testPitchToggle(); } });
        guard("buffers", new Body() { public void run() { testBuffers(); } });
        guard("lifecycle", new Body() { public void run() { testLifecycle(); } });
        guard("guard", new Body() { public void run() { testReentrancy(); } });
        guard("speed", new Body() { public void run() { testSpeed(); } });
        guard("checks", new Body() { public void run() throws Exception { testChecks(); } });
    }

    // ------------------------------------------------------------------ helpers

    private static DspParams p(float pitch, float barrel, float size, float loud, float bass,
                               float boom, float gate) {
        return new DspParams(true, pitch, barrel, size, loud, bass, boom, gate);
    }

    private static float[] sine(int sr, double freq, double amp, int n) {
        float[] x = new float[n];
        for (int i = 0; i < n; i++) x[i] = (float) (amp * Math.sin(2 * Math.PI * freq * i / sr));
        return x;
    }

    private static float[] speechLike(int sr, int n, long seed) {
        Random r = new Random(seed);
        float[] x = new float[n];
        for (int i = 0; i < n; i++) {
            double t = (double) i / sr;
            double env = 0.5 + 0.5 * Math.sin(2 * Math.PI * 3.0 * t);
            double v = 0.25 * Math.sin(2 * Math.PI * 140 * t) + 0.12 * Math.sin(2 * Math.PI * 420 * t)
                    + 0.06 * Math.sin(2 * Math.PI * 1500 * t);
            x[i] = (float) (env * v + 0.003 * (r.nextDouble() * 2 - 1));
        }
        return x;
    }

    private static float[] run(DspParams p, float[] in, int sr, int ch) {
        DophamineEngine e = new DophamineEngine(sr, ch);
        e.setParams(p);
        float[] out = in.clone();
        e.process(out, 0, out.length / ch);
        return out;
    }

    private static double rms(float[] x, int from, int to) {
        double s = 0;
        for (int i = from; i < to; i++) s += (double) x[i] * x[i];
        return Math.sqrt(s / Math.max(1, to - from));
    }

    private static double peak(float[] x, int from, int to) {
        double m = 0;
        for (int i = from; i < to; i++) m = Math.max(m, Math.abs(x[i]));
        return m;
    }

    private static double goertzel(float[] x, int from, int to, int sr, double f) {
        double c = 2 * Math.cos(2 * Math.PI * f / sr), s1 = 0, s2 = 0;
        for (int i = from; i < to; i++) {
            double s0 = x[i] + c * s1 - s2;
            s2 = s1;
            s1 = s0;
        }
        return s1 * s1 + s2 * s2 - c * s1 * s2;
    }

    private static double dominant(float[] x, int from, int to, int sr, double lo, double hi) {
        double best = lo, bp = -1;
        for (double f = lo; f <= hi; f += 4.0) {
            double pw = goertzel(x, from, to, sr, f);
            if (pw > bp) { bp = pw; best = f; }
        }
        double c = best;
        for (double f = c - 6; f <= c + 6; f += 0.25) {
            double pw = goertzel(x, from, to, sr, f);
            if (pw > bp) { bp = pw; best = f; }
        }
        return best;
    }

    // ------------------------------------------------------------------ tests

    private void testParams() {
        DspParams d = new DspParams(true, Float.NaN, 9f, -4f, 999f, Float.POSITIVE_INFINITY, Float.NaN, -500f);
        check("DspParams: NaN/диапазоны зажимаются",
                d.pitchSemitones == 0f && d.barrelMix == 1f && d.barrelSize == 0f && d.loudnessDb == 60f
                        && d.bassDb == 18f && d.boom == 0f && d.gateDb == -70f && !d.gateOn(), null);
        check("DspParams: equals/hashCode",
                DspParams.DEFAULT.equals(p(-3f, 1f, 0.65f, 12f, 6f, 0f, -48f))
                        && DspParams.DEFAULT.hashCode() == p(-3f, 1f, 0.65f, 12f, 6f, 0f, -48f).hashCode(), null);
        check("DspParams: нейтральные настройки", p(0, 0, 0, 0, 0, 0, -70).isNeutral()
                && !DspParams.DEFAULT.isNeutral() && !p(0, 0, 0, 0, 0, 0, -40).isNeutral(), null);
    }

    private void testPitch() {
        int[] rates = quick ? new int[]{48000, 16000} : new int[]{48000, 44100, 16000, 8000};
        float[] steps = quick ? new float[]{-5f, 7f, 12f} : new float[]{-12f, -5f, 3f, 7f, 12f};
        boolean allOk = true;
        StringBuilder bad = new StringBuilder();
        for (int sr : rates) {
            for (float st : steps) {
                float[] in = sine(sr, 440, 0.5, sr);
                float[] out = run(p(st, 0, 0, 0, 0, 0, -70), in, sr, 1);
                double want = 440 * Math.pow(2, st / 12.0);
                double got = dominant(out, sr / 2, sr / 2 + sr / 4, sr, want * 0.6, Math.min(want * 1.6, sr * 0.45));
                if (Math.abs(got - want) > Math.max(4.0, want * 0.012)) {
                    allOk = false;
                    bad.append(sr).append("Hz ").append(st).append("st: ждали ").append((int) want)
                            .append(" получили ").append(got).append("; ");
                }
            }
        }
        check("питч: частота сдвигается точно (8..48 кГц)", allOk, bad.toString());
    }

    private void testChunkInvariance() {
        int sr = 48000;
        DspParams boom = p(-5f, 1f, 0.9f, 48f, 15f, 1f, -40f);
        float[] mono = speechLike(sr, sr, 1);
        float[] ref = run(boom, mono, sr, 1);
        int[] cuts = {1, 3, 7, 480, 1023, 2000, 13};
        DophamineEngine e = new DophamineEngine(sr, 1);
        e.setParams(boom);
        float[] out = mono.clone();
        int pos = 0, k = 0;
        while (pos < out.length) {
            int n = Math.min(cuts[k++ % cuts.length], out.length - pos);
            e.process(out, pos, n);
            pos += n;
        }
        check("чанки: результат не зависит от размера буфера (моно)", java.util.Arrays.equals(ref, out), null);

        float[] st = new float[sr * 2];
        for (int i = 0; i < sr; i++) {
            st[2 * i] = mono[i];
            st[2 * i + 1] = mono[(i + 777) % sr] * 0.7f;
        }
        float[] sref = run(boom, st, sr, 2);
        DophamineEngine e2 = new DophamineEngine(sr, 2);
        e2.setParams(boom);
        float[] sout = st.clone();
        pos = 0;
        k = 0;
        while (pos < sr) {
            int n = Math.min(cuts[k++ % cuts.length], sr - pos);
            e2.process(sout, pos * 2, n);
            pos += n;
        }
        check("чанки: то же для стерео", java.util.Arrays.equals(sref, sout), null);
    }

    private void testStereo() {
        int sr = 48000;
        DspParams pr = p(-5f, 1f, 0.9f, 48f, 15f, 1f, -40f);
        float[] left = speechLike(sr, sr / 2, 2);
        float[] st = new float[left.length * 2];
        for (int i = 0; i < left.length; i++) st[2 * i] = left[i];
        float[] out = run(pr, st, sr, 2);
        float[] mono = run(pr, left, sr, 1);
        boolean rightSilent = true, leftSame = true;
        for (int i = 0; i < left.length; i++) {
            if (out[2 * i + 1] != 0f) rightSilent = false;
            if (out[2 * i] != mono[i]) leftSame = false;
        }
        check("стерео: каналы независимы (правый тихий, левый = моно)", rightSilent && leftSame, null);
    }

    private void testStress() {
        float[] pitches = {-12f, 0f, 12f};
        float[] zeroOne = {0f, 1f};
        float[] louds = {0f, 60f};
        float[] basses = {0f, 18f};
        float[] gates = {-70f, -20f};
        int[] rates = {48000, 8000};
        long cases = 0;
        boolean ok = true;
        String why = "";
        Random r = new Random(5);
        for (int sr : rates) {
            int n = sr / 2;
            float[] nasty = new float[n];
            for (int i = 0; i < n; i++) {
                int sec = i * 8 / n;
                switch (sec) {
                    case 0: nasty[i] = (float) (r.nextDouble() * 2 - 1); break;
                    case 1: nasty[i] = (i % 97 == 0) ? 8f : 0f; break;
                    case 2: nasty[i] = Float.NaN; break;
                    case 3: nasty[i] = (i & 1) == 0 ? Float.POSITIVE_INFINITY : Float.NEGATIVE_INFINITY; break;
                    case 4: nasty[i] = 1f; break;
                    case 5: nasty[i] = ((i / 40) & 1) == 0 ? 1f : -1f; break;
                    case 6: nasty[i] = 0f; break;
                    default: nasty[i] = (float) (0.3 * Math.sin(i * 0.05));
                }
            }
            for (float pt : pitches) for (float b : zeroOne) for (float sz : zeroOne) for (float l : louds)
                for (float bs : basses) for (float bm : zeroOne) for (float g : gates) {
                    DspParams pp = p(pt, b, sz, l, bs, bm, g);
                    float[] out = run(pp, nasty, sr, 1);
                    cases++;
                    if (pp.isNeutral()) { // neutral = bit-exact pass-through, even for garbage
                        if (!java.util.Arrays.equals(out, nasty)) {
                            ok = false;
                            why = "нейтральные настройки изменили данные";
                        }
                        continue;
                    }
                    for (int i = 0; i < out.length; i++) {
                        float v = out[i];
                        if (v != v || v > 1f || v < -1f) {
                            ok = false;
                            if (why.length() == 0) why = "sr=" + sr + " pitch=" + pt + " barrel=" + b + " size=" + sz
                                    + " loud=" + l + " bass=" + bs + " boom=" + bm + " gate=" + g + " i=" + i + " v=" + v;
                            break;
                        }
                    }
                }
        }
        check("стресс: NaN/Inf/мусор на входе -> всегда конечный выход в [-1,1] (" + cases + " комбинаций)", ok, why);
    }

    private void testSilence() {
        boolean ok = true;
        String why = "";
        for (int sr : new int[]{48000, 16000}) {
            DspParams[] ps = {
                    p(-5f, 1f, 0.9f, 60f, 18f, 1f, -40f), p(-3f, 1f, 0.65f, 12f, 6f, 0f, -48f),
                    p(12f, 0f, 0f, 60f, 0f, 0f, -70f), p(0f, 1f, 1f, 0.1f, 0f, 1f, -70f)};
            for (int k = 0; k < ps.length; k++) {
                float[] out = run(ps[k], new float[sr], sr, 2);
                if (peak(out, 0, out.length) != 0.0) { ok = false; why = "sr=" + sr + " набор " + k; }
            }
        }
        check("тишина на входе -> абсолютная тишина на выходе (нет шума/DC/ложных ударов)", ok, why);
    }

    private void testGate() {
        int sr = 48000;
        DspParams pr = p(0f, 0f, 0f, 60f, 0f, 0f, -42f);
        Random r = new Random(9);
        float[] noise = new float[sr];
        for (int i = 0; i < sr; i++) noise[i] = (float) (0.003 * (r.nextDouble() * 2 - 1));
        float[] out = run(pr, noise, sr, 1);
        check("шумодав: шум микрофона при +60 дБ не превращается в рёв", peak(out, 0, out.length) == 0.0,
                "peak=" + peak(out, 0, out.length));

        float[] in = new float[sr * 2];
        float[] tone = sine(sr, 440, 0.2, sr * 4 / 10);
        for (int i = 0; i < in.length; i++) {
            in[i] = (float) (0.003 * (r.nextDouble() * 2 - 1));
            if (i < tone.length) in[i] += tone[i];
        }
        float[] o2 = run(pr, in, sr, 1);
        double speech = peak(o2, sr / 10, tone.length);
        double after = peak(o2, sr, sr * 2);
        check("шумодав: речь проходит громко, после неё гейт закрывается", speech > 0.95 && after < 1e-4,
                "речь=" + speech + " после=" + after);

        float[] quiet = sine(sr, 300, 0.05, sr);
        float[] o3 = run(p(0f, 0f, 0f, 0.1f, 0f, 0f, -42f), quiet, sr, 1);
        double ratio = rms(o3, sr / 2, sr) / rms(quiet, sr / 2, sr);
        check("шумодав: тихая речь (-26 дБ) не режется", ratio > 0.98 && ratio < 1.02, "ratio=" + ratio);
    }

    private void testLoudness() {
        int sr = 48000;
        float[] in = sine(sr, 300, 0.01, sr);
        float[] o20 = run(p(0f, 0f, 0f, 20f, 0f, 0f, -70f), in, sr, 1);
        double r20 = rms(o20, sr / 2, sr) / rms(in, sr / 2, sr);
        check("громкость: +20 дБ = ровно x10 без искажений", Math.abs(r20 - 10.0) < 0.3, "x" + r20);
        float[] o60 = run(p(0f, 0f, 0f, 60f, 0f, 0f, -70f), in, sr, 1);
        double pk = peak(o60, sr / 2, sr);
        check("громкость: +60 дБ упирается в потолок, но не выше 0 dBFS", pk > 0.99 && pk <= 1.0, "peak=" + pk);
        boolean mono = true;
        for (float v = 0f; v < 3f; v += 0.001f) {
            if (Saturator.soft(v) < Saturator.soft(v - 0.001f) - 1e-7f || Saturator.soft(v) > 1.0f) mono = false;
        }
        check("лимитер: монотонный, не превышает 1.0", mono, null);
    }

    private void testBarrel() {
        int sr = 48000;
        DspParams pr = p(0f, 1f, 0.6f, 0.1f, 0f, 0f, -70f);
        float[] hi = sine(sr, 8000, 0.3, sr);
        float[] lo = sine(sr, 300, 0.3, sr);
        double hiDb = 20 * Math.log10(rms(run(pr, hi, sr, 1), sr / 2, sr) / rms(hi, sr / 2, sr));
        double loDb = 20 * Math.log10(rms(run(pr, lo, sr, 1), sr / 2, sr) / rms(lo, sr / 2, sr));
        check("бочка: верха глушатся (8 кГц ослаблены), басы/середина живы",
                hiDb < -12.0 && loDb > -3.0, String.format("8к: %.1f дБ, 300 Гц: %.1f дБ", hiDb, loDb));
        float[] imp = new float[sr / 2];
        imp[100] = 0.5f;
        float[] ir = run(pr, imp, sr, 1);
        double tail = rms(ir, 100 + sr / 50, 100 + sr / 8);
        check("бочка: у импульса есть металлический хвост (20..125 мс)", tail > 1e-4, "rms=" + tail);
        check("бочка: хвост затухает (нет самовозбуждения)", rms(ir, sr / 4, sr / 2) < tail * 0.1, null);
    }

    private void testBoom() {
        int sr = 48000;
        DspParams on = p(0f, 0f, 0f, 0.1f, 0f, 1f, -70f);
        DspParams off = p(0f, 0f, 0f, 0.1f, 0f, 0f, -70f);
        float[] in = new float[sr * 2];
        float[] tone = sine(sr, 600, 0.3, sr / 5);
        System.arraycopy(tone, 0, in, sr * 3 / 10, tone.length);
        float[] a = run(on, in, sr, 1);
        float[] b = run(off, in, sr, 1);
        double ra = rms(a, sr * 55 / 100, sr * 85 / 100);
        double rb = rms(b, sr * 55 / 100, sr * 85 / 100);
        double f = dominant(a, sr * 55 / 100, sr * 85 / 100, sr, 20, 400);
        check("звуковой удар: после слова слышен суббас-гул (30..150 Гц)", ra > 0.05 && rb == 0.0 && f < 150,
                "rms=" + ra + " f=" + f + " без удара=" + rb);
        Random r = new Random(3);
        float[] noise = new float[sr];
        for (int i = 0; i < sr; i++) noise[i] = (float) (0.002 * (r.nextDouble() * 2 - 1));
        check("звуковой удар: фоновый шум его не запускает", peak(run(on, noise, sr, 1), 0, sr) < 0.0021, null);
        float[] cont = sine(sr, 600, 0.3, sr * 2);
        float[] c = run(on, cont, sr, 1);
        check("звуковой удар: на непрерывный звук - один удар, а не пулемёт",
                rms(c, sr, sr * 2) < 0.25, "rms=" + rms(c, sr, sr * 2));
    }

    private void testTailDies() {
        int sr = 48000;
        DspParams pr = p(-5f, 1f, 0.9f, 48f, 15f, 1f, -40f);
        float[] in = new float[sr * 4];
        float[] tone = sine(sr, 300, 0.3, sr / 2);
        System.arraycopy(tone, 0, in, 0, tone.length);
        float[] out = run(pr, in, sr, 1);
        double late = peak(out, sr * 3, sr * 4);
        check("«звуковой барьер»: хвост (реверб + удар) полностью затухает за 3 с", late < 1e-4, "peak=" + late);
    }

    private void testPitchToggle() {
        int sr = 48000;
        float[] in = sine(sr, 200, 0.3, sr);
        DophamineEngine e = new DophamineEngine(sr, 1);
        float[] out = in.clone();
        e.setParams(p(0f, 0.2f, 0.2f, 0.1f, 0f, 0f, -70f));
        e.process(out, 0, sr / 2);
        e.setParams(p(5f, 0.2f, 0.2f, 0.1f, 0f, 0f, -70f));
        e.process(out, sr / 2, sr / 4);
        e.setParams(p(0f, 0.2f, 0.2f, 0.1f, 0f, 0f, -70f));
        e.process(out, sr * 3 / 4, sr / 4);
        double maxJump = 0;
        for (int i = 1; i < out.length; i++) maxJump = Math.max(maxJump, Math.abs(out[i] - out[i - 1]));
        check("питч: включение/выключение на лету без щелчков", maxJump < 0.12, "max скачок=" + maxJump);
    }

    // ---------------------------------------------------------------- buffer glue

    private static byte[] toBytes16(short[] s) {
        byte[] b = new byte[s.length * 2];
        for (int i = 0; i < s.length; i++) {
            b[2 * i] = (byte) s[i];
            b[2 * i + 1] = (byte) (s[i] >> 8);
        }
        return b;
    }

    private static short[] fromBytes16(byte[] b) {
        short[] s = new short[b.length / 2];
        for (int i = 0; i < s.length; i++) s[i] = (short) ((b[2 * i] & 0xFF) | (b[2 * i + 1] << 8));
        return s;
    }

    private void testBuffers() {
        int sr = 48000;
        DspParams pr = p(-3f, 1f, 0.65f, 12f, 6f, 0f, -48f);
        float[] f = speechLike(sr, 4096, 7);
        short[] src = new short[f.length];
        for (int i = 0; i < f.length; i++) src[i] = BufferProcessor.toShort(f[i] * 0.9f);

        // reference through the plain engine
        float[] ref = new float[src.length];
        for (int i = 0; i < ref.length; i++) ref[i] = src[i] / 32768f;
        DophamineEngine e = new DophamineEngine(sr, 1);
        e.setParams(pr);
        e.process(ref, 0, ref.length);
        short[] want = new short[ref.length];
        for (int i = 0; i < ref.length; i++) want[i] = BufferProcessor.toShort(ref[i]);

        // short[] with offset and guard zones
        short[] big = new short[src.length + 10];
        java.util.Arrays.fill(big, (short) 1234);
        System.arraycopy(src, 0, big, 5, src.length);
        int n = new BufferProcessor().processShorts(new Object(), big, 5, src.length, sr, 1, pr);
        boolean guards = true;
        for (int i = 0; i < 5; i++) if (big[i] != 1234 || big[big.length - 1 - i] != 1234) guards = false;
        boolean same = n == src.length;
        for (int i = 0; i < src.length && same; i++) if (big[5 + i] != want[i]) same = false;
        check("short[]: offset/границы соблюдены, результат = движок", guards && same, "n=" + n);

        // byte[] LE
        byte[] bytes = toBytes16(src);
        int nb = new BufferProcessor().processBytes(new Object(), bytes, 0, bytes.length, 2, sr, 1, pr);
        check("byte[]: PCM16 little-endian даёт тот же результат, что short[]",
                nb == src.length && java.util.Arrays.equals(fromBytes16(bytes), want), "n=" + nb);

        // float[]
        float[] fl = new float[src.length];
        for (int i = 0; i < fl.length; i++) fl[i] = src[i] / 32768f;
        int nf = new BufferProcessor().processFloats(new Object(), fl, 0, fl.length, sr, 1, pr);
        check("float[]: совпадает с движком", nf == fl.length && java.util.Arrays.equals(fl, ref), null);

        // float PCM inside byte[] / ByteBuffer
        byte[] fb = new byte[src.length * 4];
        ByteBuffer wrap = ByteBuffer.wrap(fb).order(java.nio.ByteOrder.LITTLE_ENDIAN);
        for (int i = 0; i < src.length; i++) wrap.putFloat(src[i] / 32768f);
        int nfb = new BufferProcessor().processBytes(new Object(), fb, 0, fb.length, 4, sr, 1, pr);
        wrap.clear();
        boolean fsame = nfb == src.length;
        for (int i = 0; i < src.length && fsame; i++) if (wrap.getFloat() != ref[i]) fsame = false;
        check("byte[] с ENCODING_PCM_FLOAT", fsame, null);

        // direct ByteBuffer: position/limit untouched, content processed from index 0
        ByteBuffer dbb = ByteBuffer.allocateDirect(src.length * 2 + 64);
        byte[] raw = toBytes16(src);
        dbb.put(raw, 0, raw.length);
        dbb.position(7);
        dbb.limit(10);
        int ndb = new BufferProcessor().processByteBuffer(new Object(), dbb, raw.length, 2, sr, 1, pr);
        byte[] back = new byte[raw.length];
        ByteBuffer dup = dbb.duplicate();
        dup.clear();
        dup.get(back, 0, back.length);
        check("ByteBuffer (direct): position/limit не тронуты, данные обработаны",
                ndb == src.length && dbb.position() == 7 && dbb.limit() == 10
                        && java.util.Arrays.equals(fromBytes16(back), want), "n=" + ndb);

        // stereo with odd count: trailing half-frame untouched
        short[] odd = new short[2001];
        for (int i = 0; i < odd.length; i++) odd[i] = (short) (i * 11 - 8000);
        short last = odd[2000];
        int no = new BufferProcessor().processShorts(new Object(), odd, 0, odd.length, sr, 2, pr);
        check("стерео с нечётным числом сэмплов: неполный кадр не трогаем", no == 2000 && odd[2000] == last, "n=" + no);

        // bad arguments never throw
        BufferProcessor bp = new BufferProcessor();
        Object k = new Object();
        boolean noThrow = true;
        try {
            bp.processShorts(null, new short[8], 0, 8, sr, 1, pr);
            bp.processShorts(k, null, 0, 8, sr, 1, pr);
            bp.processShorts(k, new short[8], -1, 8, sr, 1, pr);
            bp.processShorts(k, new short[8], 8, 8, sr, 1, pr);
            bp.processShorts(k, new short[8], 2, 100, sr, 1, pr);
            bp.processShorts(k, new short[8], 0, 0, sr, 1, pr);
            bp.processShorts(k, new short[8], 0, 8, 0, 0, pr);
            bp.processShorts(k, new short[8], 0, 8, -5, 9, pr);
            bp.processShorts(k, new short[8], 0, 8, sr, 1, null);
            bp.processBytes(k, new byte[7], 0, 7, 2, sr, 1, pr);
            bp.processBytes(k, new byte[7], 0, 7, 3, sr, 1, pr);
            bp.processByteBuffer(k, null, 8, 2, sr, 1, pr);
            bp.processByteBuffer(k, ByteBuffer.allocate(8).asReadOnlyBuffer(), 8, 2, sr, 1, pr);
        } catch (Throwable t) {
            noThrow = false;
        }
        check("кривые аргументы (null, off<0, count>длины, ch=0/9, read-only) не роняют процесс", noThrow, null);

        byte[] eight = {1, 2, 3, 4, 5, 6, 7, 8};
        byte[] eightCopy = eight.clone();
        int n8 = bp.processBytes(k, eight, 0, 8, 3, sr, 1, pr);
        check("8-bit PCM пропускается без изменений", n8 == -1 && java.util.Arrays.equals(eight, eightCopy), null);

        short[] neutral = {1, -2, 3, -4, 5};
        short[] nc = neutral.clone();
        int nn = bp.processShorts(k, neutral, 0, 5, sr, 1, p(0, 0, 0, 0, 0, 0, -70));
        int nd = bp.processShorts(k, neutral, 0, 5, sr, 1, new DspParams(false, -3f, 1f, 1f, 12f, 6f, 1f, -40f));
        check("нейтральные/выключенные настройки: аудио бит-в-бит как есть",
                nn == -1 && nd == -1 && java.util.Arrays.equals(neutral, nc), null);
    }

    private void testLifecycle() {
        int sr = 48000;
        DspParams pr = p(-3f, 1f, 0.9f, 20f, 6f, 1f, -70f);
        BufferProcessor bp = new BufferProcessor();
        Object a = new Object(), b = new Object();

        short[] loud = new short[sr / 4];
        for (int i = 0; i < loud.length; i++) loud[i] = (short) (12000 * Math.sin(2 * Math.PI * 300 * i / sr));
        bp.processShorts(a, loud, 0, loud.length, sr, 1, pr);

        short[] zerosB = new short[sr / 4];
        bp.processShorts(b, zerosB, 0, zerosB.length, sr, 1, pr);
        check("у каждого AudioRecord своё состояние (хвост A не утекает в B)", peak16(zerosB) == 0, null);

        // disable -> data untouched; enable again -> old tail must be gone
        DspParams off = new DspParams(false, -3f, 1f, 0.9f, 20f, 6f, 1f, -70f);
        short[] during = new short[sr / 2];
        for (int i = 0; i < during.length; i++) during[i] = 100;
        short[] duringCopy = during.clone();
        bp.processShorts(a, during, 0, during.length, sr, 1, off);
        short[] zerosA = new short[sr / 4];
        bp.processShorts(a, zerosA, 0, zerosA.length, sr, 1, pr);
        check("выкл -> вкл: старый хвост не вылезает, пока эффект был выключен",
                java.util.Arrays.equals(during, duringCopy) && peak16(zerosA) == 0, "peak=" + peak16(zerosA));

        // restart of recording
        bp.processShorts(a, loud.clone(), 0, loud.length, sr, 1, pr);
        bp.markIdle(a);
        short[] z2 = new short[sr / 8];
        bp.processShorts(a, z2, 0, z2.length, sr, 1, pr);
        check("startRecording сбрасывает состояние", peak16(z2) == 0, null);

        // sample-rate / channel change on the same recorder
        boolean ok = true;
        try {
            short[] t = new short[2000];
            bp.processShorts(a, t, 0, 2000, 16000, 1, pr);
            bp.processShorts(a, t, 0, 2000, 44100, 2, pr);
            bp.processShorts(a, t, 0, 2000, 48000, 1, pr);
        } catch (Throwable t) {
            ok = false;
        }
        check("смена частоты/каналов на том же рекордере пересоздаёт движок без ошибок", ok, null);

        // live parameter change while streaming
        boolean live = true;
        short[] chunk = new short[960];
        for (int i = 0; i < chunk.length; i++) chunk[i] = (short) (8000 * Math.sin(i * 0.1));
        Object c = new Object();
        for (int k = 0; k < 200; k++) {
            DspParams q = p((k % 25) - 12f, (k % 11) / 10f, (k % 7) / 6f, (k % 13) * 4.6f, (k % 5) * 4f,
                    (k % 3) / 2f, -70f + (k % 4) * 10f);
            short[] cc = chunk.clone();
            bp.processShorts(c, cc, 0, cc.length, sr, 1, q);
        }
        check("параметры меняются на лету без исключений", live, null);
    }

    private static int peak16(short[] s) {
        int m = 0;
        for (short v : s) m = Math.max(m, Math.abs((int) v));
        return m;
    }

    private void testReentrancy() {
        final ReentrancyGuard g = new ReentrancyGuard();
        boolean a = g.enter();       // outer
        boolean b = g.enter();       // nested read(..., READ_BLOCKING)
        boolean c = g.enter();
        g.exit();
        g.exit();
        g.exit();
        boolean d = g.enter();       // outer again
        g.exit();
        g.exit();
        g.exit();                    // extra exit must not go negative
        boolean e = g.enter();
        g.exit();
        check("защита от двойной обработки вложенных read(): только внешний вызов обрабатывает",
                a && !b && !c && d && e, null);

        final boolean[] other = new boolean[1];
        g.enter();
        Thread t = new Thread(new Runnable() {
            public void run() {
                other[0] = g.enter();
                g.exit();
            }
        });
        t.start();
        try {
            t.join();
        } catch (InterruptedException ignored) {
        }
        g.exit();
        check("защита: счётчики потоков независимы", other[0], null);

        boolean healed = false;
        for (int i = 0; i < 40; i++) if (g.enter()) healed = true;
        check("защита: потерянный exit() не блокирует обработку навсегда", healed, null);
    }

    // ---------------------------------------------------------------- framework checks

    private static void put32(byte[] d, int o, int v) {
        d[o] = (byte) v;
        d[o + 1] = (byte) (v >> 8);
        d[o + 2] = (byte) (v >> 16);
        d[o + 3] = (byte) (v >> 24);
    }

    /** Minimal valid-enough DEX: string_ids, type_ids and class_defs (what DexProbe reads). */
    private static byte[] fakeDex(String[] strs, int[] typeToStr, int[] classTypes) {
        int n = strs.length, t = typeToStr.length, c = classTypes.length;
        int strIds = 0x70, typeIds = strIds + n * 4, classDefs = typeIds + t * 4, data = classDefs + c * 32;
        int size = data;
        for (String x : strs) size += 1 + x.length() + 1;
        byte[] d = new byte[size];
        d[0] = 'd'; d[1] = 'e'; d[2] = 'x'; d[3] = '\n'; d[4] = '0'; d[5] = '3'; d[6] = '5';
        put32(d, 0x38, n); put32(d, 0x3C, strIds);
        put32(d, 0x40, t); put32(d, 0x44, typeIds);
        put32(d, 0x60, c); put32(d, 0x64, classDefs);
        int p = data;
        for (int i = 0; i < n; i++) {
            put32(d, strIds + i * 4, p);
            d[p++] = (byte) strs[i].length();
            for (int k = 0; k < strs[i].length(); k++) d[p++] = (byte) strs[i].charAt(k);
            d[p++] = 0;
        }
        for (int i = 0; i < t; i++) put32(d, typeIds + i * 4, typeToStr[i]);
        for (int i = 0; i < c; i++) put32(d, classDefs + i * 32, classTypes[i]);
        return d;
    }

    private void testChecks() throws Exception {
        String[] strs = {"Lcom/foo/A;", "Lde/robv/android/xposed/XposedBridge;"};
        String px = com.dophamine.voice.check.DexProbe.XPOSED_PREFIX;
        byte[] referencedOnly = fakeDex(strs, new int[]{0, 1}, new int[]{0});
        byte[] defined = fakeDex(strs, new int[]{0, 1}, new int[]{0, 1});
        check("DEX: класс только упомянут (как в нормальном модуле) -> API не зашит",
                !com.dophamine.voice.check.DexProbe.definesClassWithPrefix(referencedOnly, px), null);
        check("DEX: класс Xposed определён в dex -> API зашит",
                com.dophamine.voice.check.DexProbe.definesClassWithPrefix(defined, px), null);
        byte[] cut = java.util.Arrays.copyOf(defined, defined.length - 30);
        byte[] garbage = new byte[400];
        new Random(1).nextBytes(garbage);
        boolean noCrash = true;
        try {
            com.dophamine.voice.check.DexProbe.definesClassWithPrefix(cut, px);
            com.dophamine.voice.check.DexProbe.definesClassWithPrefix(garbage, px);
            com.dophamine.voice.check.DexProbe.definesClassWithPrefix(new byte[3], px);
            com.dophamine.voice.check.DexProbe.definesClassWithPrefix(null, px);
        } catch (Throwable t) {
            noCrash = false;
        }
        check("DEX: обрезанный/мусорный/пустой файл не роняет проверку", noCrash, null);

        java.io.File tmp = java.io.File.createTempFile("dophamine", ".apk");
        try {
            for (int variant = 0; variant < 3; variant++) {
                java.util.zip.ZipOutputStream z = new java.util.zip.ZipOutputStream(new java.io.FileOutputStream(tmp));
                if (variant == 0) { z.putNextEntry(new java.util.zip.ZipEntry("classes.dex")); z.write(referencedOnly); z.closeEntry(); }
                if (variant == 1) {
                    z.putNextEntry(new java.util.zip.ZipEntry("classes.dex")); z.write(referencedOnly); z.closeEntry();
                    z.putNextEntry(new java.util.zip.ZipEntry("classes2.dex")); z.write(defined); z.closeEntry();
                }
                if (variant == 2) { z.putNextEntry(new java.util.zip.ZipEntry("res/a.txt")); z.write(1); z.closeEntry(); }
                z.close();
                int r = com.dophamine.voice.check.DexProbe.apkDefinesXposedApi(tmp.getPath());
                int want = variant == 0 ? 0 : (variant == 1 ? 1 : -1);
                check("APK: " + (variant == 0 ? "чистый" : variant == 1 ? "API во втором dex" : "без dex") + " -> " + want,
                        r == want, "получили " + r);
            }
        } finally {
            tmp.delete();
        }
        check("APK: несуществующий файл -> -1", com.dophamine.voice.check.DexProbe.apkDefinesXposedApi("/no/such.apk") == -1, null);

        com.dophamine.voice.check.FrameworkCheck.State A = com.dophamine.voice.check.FrameworkCheck.State.ACTIVE;
        com.dophamine.voice.check.FrameworkCheck.State N = com.dophamine.voice.check.FrameworkCheck.State.NEEDS_SETUP;
        com.dophamine.voice.check.FrameworkCheck.State F = com.dophamine.voice.check.FrameworkCheck.State.NOT_FOUND;
        com.dophamine.voice.check.FrameworkCheck.State B = com.dophamine.voice.check.FrameworkCheck.State.API_BUNDLED;
        long fresh = 60000L, stale = com.dophamine.voice.check.FrameworkCheck.PING_FRESH_MS + 1;
        boolean ok = com.dophamine.voice.check.FrameworkCheck.verdict(true, true, true, true, 0) == B   // зашитый API бьёт всё
                && com.dophamine.voice.check.FrameworkCheck.verdict(false, false, false, true, -1) == A
                && com.dophamine.voice.check.FrameworkCheck.verdict(false, true, false, false, fresh) == A
                && com.dophamine.voice.check.FrameworkCheck.verdict(false, true, false, false, stale) == N
                && com.dophamine.voice.check.FrameworkCheck.verdict(false, false, true, false, -1) == N
                && com.dophamine.voice.check.FrameworkCheck.verdict(false, true, false, false, -1) == N
                && com.dophamine.voice.check.FrameworkCheck.verdict(false, false, false, false, -1) == F
                && com.dophamine.voice.check.FrameworkCheck.verdict(false, false, false, false, stale) == F;
        check("вердикт LSPosed/Vector: API внутри APK > активен > нужна настройка > не найден", ok, null);

        boolean maps = com.dophamine.voice.check.FrameworkCheck.isInjectionTrace("7f1 r-xp /data/adb/modules/zygisk_lsposed/lib/arm64/liblspd.so")
                && com.dophamine.voice.check.FrameworkCheck.isInjectionTrace("7f2 r-xp /memfd:zygisk (deleted)")
                && com.dophamine.voice.check.FrameworkCheck.isInjectionTrace("7f3 r-xp /data/adb/modules/zygisk_vector/x.so")
                && !com.dophamine.voice.check.FrameworkCheck.isInjectionTrace("7f4 r-xp /system/lib64/libc.so")
                && !com.dophamine.voice.check.FrameworkCheck.isInjectionTrace("7f5 r-xp /data/app/com.dophamine.voice-1/base.apk")
                && !com.dophamine.voice.check.FrameworkCheck.isInjectionTrace(null);
        check("следы инжекта: находит Zygisk/LSPosed, не путает системные библиотеки", maps, null);
    }

    private void testSpeed() {
        int sr = 48000;
        int seconds = quick ? 2 : 10;
        float[] st = new float[sr * 2 * seconds];
        float[] m = speechLike(sr, sr * seconds, 11);
        for (int i = 0; i < m.length; i++) {
            st[2 * i] = m[i];
            st[2 * i + 1] = m[i];
        }
        DophamineEngine e = new DophamineEngine(sr, 2);
        e.setParams(p(-5f, 1f, 0.9f, 48f, 15f, 1f, -40f));
        long t0 = System.nanoTime();
        int chunk = 1920;
        for (int pos = 0; pos < sr * seconds; pos += chunk) {
            e.process(st, pos * 2, Math.min(chunk, sr * seconds - pos));
        }
        double sec = (System.nanoTime() - t0) / 1e9;
        double rtf = seconds / sec;
        check("скорость: «Звуковой барьер» 48 кГц стерео быстрее реального времени", rtf > 3.0,
                String.format("x%.1f реального времени", rtf));
    }
}
