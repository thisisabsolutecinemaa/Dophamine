package com.dophamine.voice;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.io.File;
import java.util.HashSet;
import java.util.Set;

/**
 * Asks LSPosed / Vector which apps are in this module's scope. Needs root: the config database
 * lives in /data/adb/lspd. It is copied into the app cache and opened read-only, nothing is changed.
 */
final class LspScope {
    private static final String DB_DIR = "/data/adb/lspd/config/";

    static final class Result {
        boolean rootOk;
        boolean dbOk;
        boolean moduleFound;
        boolean enabled;
        final Set<String> scope = new HashSet<String>();
        String error;
    }

    private LspScope() {}

    /** Blocking (su). Call from a background thread. */
    static Result query(Context ctx, String modulePkg) {
        Result r = new Result();
        String id = RootShell.run("id -u", 20);
        if (id == null || !id.trim().startsWith("0")) {
            r.error = "root недоступен";
            return r;
        }
        r.rootOk = true;
        File dir = new File(ctx.getCacheDir(), "lsp");
        dir.mkdirs();
        String d = dir.getAbsolutePath();
        RootShell.run("rm -f " + d + "/modules_config.db*; "
                + "for f in modules_config.db modules_config.db-wal modules_config.db-shm; do "
                + "cp " + DB_DIR + "$f " + d + "/ 2>/dev/null; done; chmod 666 " + d + "/modules_config.db*", 20);
        File db = new File(dir, "modules_config.db");
        if (!db.exists() || db.length() == 0) {
            r.error = "база LSPosed не найдена";
            return r;
        }
        SQLiteDatabase sql = null;
        Cursor c = null;
        try {
            sql = SQLiteDatabase.openDatabase(db.getPath(), null, SQLiteDatabase.OPEN_READONLY);
            c = sql.rawQuery("SELECT mid, enabled FROM modules WHERE module_pkg_name = ?", new String[]{modulePkg});
            if (c.moveToFirst()) {
                r.moduleFound = true;
                long mid = c.getLong(0);
                r.enabled = c.getInt(1) != 0;
                c.close();
                c = sql.rawQuery("SELECT DISTINCT app_pkg_name FROM scope WHERE mid = ?",
                        new String[]{String.valueOf(mid)});
                while (c.moveToNext()) r.scope.add(c.getString(0));
            }
            r.dbOk = true;
        } catch (Throwable t) {
            r.error = String.valueOf(t);
        } finally {
            try {
                if (c != null) c.close();
            } catch (Throwable ignored) {
            }
            try {
                if (sql != null) sql.close();
            } catch (Throwable ignored) {
            }
            RootShell.run("rm -f " + d + "/modules_config.db*", 10);
        }
        return r;
    }
}
