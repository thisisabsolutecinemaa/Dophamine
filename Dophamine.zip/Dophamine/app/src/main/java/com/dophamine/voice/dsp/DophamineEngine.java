package com.dophamine.voice.dsp;

/**
 * Multi-channel streaming engine. Works on interleaved float samples in
 * [-1, 1], one independent {@link ChannelChain} per channel. Stateful: the
 * result does not depend on how the stream is cut into chunks.
 */
public final class DophamineEngine {
    private static final float IN_LIMIT = 8f;

    private final int channels;
    private final ChannelChain[] chains;
    private DspParams params;

    public DophamineEngine(int sampleRate, int channels) {
        int sr = Math.max(8000, Math.min(192000, sampleRate));
        this.channels = Math.max(1, Math.min(BufferProcessor.MAX_CHANNELS, channels));
        chains = new ChannelChain[this.channels];
        for (int i = 0; i < chains.length; i++) chains[i] = new ChannelChain(sr);
    }

    public int channels() {
        return channels;
    }

    public void setParams(DspParams p) {
        if (p == null || p == params) return;
        if (p.equals(params)) {
            params = p;
            return;
        }
        for (ChannelChain c : chains) c.configure(p);
        params = p;
    }

    public void reset() {
        for (ChannelChain c : chains) c.reset();
    }

    /**
     * Processes {@code frames} frames in place starting at {@code off}.
     * Disabled / neutral settings leave the buffer untouched.
     */
    public void process(float[] data, int off, int frames) {
        DspParams p = params;
        if (data == null || frames <= 0 || p == null || !p.enabled || p.isNeutral()) return;
        int n = frames * channels;
        if (off < 0 || n / channels != frames || off > data.length - n) {
            throw new IllegalArgumentException("buffer too small");
        }
        for (int f = 0; f < frames; f++) {
            int base = off + f * channels;
            for (int c = 0; c < channels; c++) {
                float x = data[base + c];
                if (x != x) x = 0f;                       // NaN
                else if (x > IN_LIMIT) x = IN_LIMIT;      // +-Inf and garbage
                else if (x < -IN_LIMIT) x = -IN_LIMIT;
                float y = chains[c].process(x);
                if (y != y) {                             // NaN got into a feedback loop: wipe it
                    chains[c].reset();
                    y = 0f;
                } else if (y > 1f) y = 1f;
                else if (y < -1f) y = -1f;
                data[base + c] = y;
            }
        }
    }
}
