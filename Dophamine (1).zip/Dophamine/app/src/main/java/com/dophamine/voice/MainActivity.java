package com.dophamine.voice;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.dophamine.voice.check.DexProbe;
import com.dophamine.voice.check.FrameworkCheck;
import com.dophamine.voice.dsp.BufferProcessor;
import com.dophamine.voice.dsp.DspParams;
import com.dophamine.voice.dsp.DspSelfTest;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Settings screen of the Dophamine LSPosed/Vector module. Plain framework widgets, no AppCompat. */
public class MainActivity extends Activity {
    private static final int BG = 0xFF0E0F14;
    private static final int CARD = 0xFF181A22;
    private static final int CHIP = 0xFF262A36;
    private static final int ACCENT = 0xFFFF6B3D;
    private static final int TEXT = 0xFFECEEF4;
    private static final int MUTED = 0xFF8B90A0;
    private static final int GOOD = 0xFF4CD08B;
    private static final int WARN = 0xFFFFB84D;
    private static final int BAD = 0xFFFF5A5A;

    private static final int REQ_MIC = 42;
    private static final float PREVIEW_VOLUME = 0.25f;

    private static final int FMT_SEMITONES = 0;
    private static final int FMT_PERCENT = 1;
    private static final int FMT_PLUS_DB = 2;
    private static final int FMT_GATE = 3;

    /** Replaced by the hook with "return true" when the module is active inside its own process. */
    static boolean isModuleActive() {
        return false;
    }

    private SharedPreferences prefs;
    private final List<Row> rows = new ArrayList<Row>();
    private final List<Button> presetButtons = new ArrayList<Button>();
    private boolean updatingUi;
    private volatile boolean previewRunning;

    private Switch master;
    private TextView statusTitle;
    private TextView statusBody;
    private LinearLayout checksBox;
    private TextView targetsSummary;
    private Button openBtn;
    private TextView previewStatus;
    private TextView testOutput;
    private Button previewBtn;
    private Button testBtn;
    private String[] framework; // {label, version, package} of the installed LSPosed/Vector, or null

    // ------------------------------------------------------------------ lifecycle

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = openPrefs();
        Config.ensureDefaults(prefs);
        setContentView(buildUi());
        loadFromPrefs();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshStatus();
        refreshTargets();
    }

    @Override
    protected void onPause() {
        super.onPause();
        makeReadable();
    }

    private SharedPreferences openPrefs() {
        return Config.open(this);
    }

    /** Best effort: let the hooked process read the prefs file even without LSPosed's file redirection. */
    private void makeReadable() {
        try {
            File dir = new File(getApplicationInfo().dataDir, "shared_prefs");
            dir.setExecutable(true, false);
            dir.setReadable(true, false);
            File f = new File(dir, Config.PREFS + ".xml");
            if (f.exists()) f.setReadable(true, false);
        } catch (Throwable ignored) {
        }
    }

    // ------------------------------------------------------------------ LSPosed / Vector detection

    /**
     * Looks for the LSPosed / Vector manager among installed apps (package name or label), so the
     * app knows the framework is there even before the module is enabled.
     */
    private String[] findFramework() {
        try {
            PackageManager pm = getPackageManager();
            String self = getPackageName();
            List<ApplicationInfo> apps = pm.getInstalledApplications(0);
            for (ApplicationInfo ai : apps) {
                if (ai.packageName == null || ai.packageName.equals(self)) continue;
                String pkg = ai.packageName.toLowerCase(Locale.ROOT);
                String label = String.valueOf(pm.getApplicationLabel(ai));
                String low = label.toLowerCase(Locale.ROOT);
                boolean hit = pkg.contains("lsposed")
                        || (pkg.contains("vector") && pkg.contains("manager"))
                        || low.contains("lsposed")
                        || low.equals("vector");
                if (!hit) continue;
                String version = "";
                try {
                    String v = pm.getPackageInfo(ai.packageName, 0).versionName;
                    if (v != null) version = v;
                } catch (Throwable ignored) {
                }
                return new String[]{label, version, ai.packageName};
            }
        } catch (Throwable ignored) {
        }
        return null;
    }

    private void refreshStatus() {
        framework = findFramework();
        boolean managerFound = framework != null;
        boolean moduleLoaded = isModuleActive();
        int bundled = DexProbe.apkDefinesXposedApi(getPackageCodePath());
        boolean traces = FrameworkCheck.hasInjectionTraces();

        SharedPreferences st = getSharedPreferences(Config.STATE_PREFS, MODE_PRIVATE);
        String pkg = st.getString(Config.ST_LAST_PKG, null);
        long t = st.getLong(Config.ST_LAST_TIME, 0L);
        boolean pinged = pkg != null && t > 0L;
        long age = pinged ? Math.max(0L, System.currentTimeMillis() - t) : -1L;

        FrameworkCheck.State state = FrameworkCheck.verdict(bundled == 1, managerFound, traces, moduleLoaded, age);
        String fw = managerFound
                ? (framework[0] + (framework[1].length() > 0 ? " " + framework[1] : ""))
                : "LSPosed / Vector";
        switch (state) {
            case ACTIVE:
                statusTitle.setText("● Модуль активен");
                statusTitle.setTextColor(GOOD);
                statusBody.setText("Фреймворк работает: " + fw + ".");
                break;
            case NEEDS_SETUP:
                statusTitle.setText("● " + fw + " найден, модуль не подключён");
                statusTitle.setTextColor(WARN);
                statusBody.setText("1. В менеджере открой «Модули» и включи Dophamine.\n"
                        + "2. В области действия отметь сам Dophamine и приложения, чей микрофон менять.\n"
                        + "3. Останови эти приложения принудительно и снова открой Dophamine.");
                break;
            case API_BUNDLED:
                statusTitle.setText("● В APK зашит Xposed API");
                statusTitle.setTextColor(BAD);
                statusBody.setText("Vector не загрузит такой модуль («Cannot load module» в логе). Собери APK через "
                        + "GitHub Actions (см. README) или удали пакет de.robv.android.xposed из classes.dex.");
                break;
            default:
                statusTitle.setText("● LSPosed / Vector не найден");
                statusTitle.setTextColor(BAD);
                statusBody.setText("Модулю нужен установленный и работающий LSPosed или Vector. Если он стоит, "
                        + "а здесь не виден, проверь в настройках системы доступ Dophamine к списку приложений.");
                break;
        }
        openBtn.setVisibility(managerFound ? View.VISIBLE : View.GONE);

        checksBox.removeAllViews();
        addCheck(bundled == 0 ? 1 : (bundled == 1 ? 0 : -1),
                bundled == 0 ? "Xposed API не зашит в APK"
                        : (bundled == 1 ? "Xposed API зашит в APK" : "APK прочитать не удалось"));
        addCheck(managerFound ? 1 : 0, managerFound ? "Менеджер установлен: " + fw : "Менеджер LSPosed / Vector не найден");
        addCheck(traces ? 1 : -1, traces ? "В процессе есть следы Zygisk / LSPosed"
                : "Следов инжекта в процессе не видно (их могут скрывать)");
        addCheck(moduleLoaded ? 1 : 0, moduleLoaded ? "Модуль загружен фреймворком"
                : "Модуль не загружен (включи его и отметь сам Dophamine в области действия)");
        if (pinged) {
            boolean cfg = st.getBoolean(Config.ST_LAST_CFG, false);
            boolean allowed = st.getBoolean(Config.ST_LAST_ALLOWED, true);
            addCheck(1, "Хук сработал в " + pkg + " · " + ago(age));
            addCheck(cfg ? 1 : 0, cfg ? "Настройки доходят до хука"
                    : "Настройки не дошли до хука: работают значения пресета «Бочка»");
            addCheck(allowed ? 1 : -1, allowed ? "Приложение входит в цели"
                    : "Приложение не в списке целей: звук там не меняется");
        } else {
            addCheck(-1, "Хук ещё не срабатывал: запиши голосовое или позвони в выбранном приложении");
        }
    }

    private void addCheck(int state, String msg) {
        String mark = state > 0 ? "✓ " : (state == 0 ? "✗ " : "• ");
        int color = state > 0 ? GOOD : (state == 0 ? BAD : MUTED);
        TextView t = text(mark + msg, 13, color, false);
        t.setPadding(0, dp(3), 0, dp(3));
        checksBox.addView(t);
    }

    private void refreshTargets() {
        boolean only = Config.onlySelected(prefs);
        int n = Config.targets(prefs).size();
        if (!only) {
            targetsSummary.setText("Звук меняется во всех приложениях из области действия LSPosed. Можно ограничить списком.");
            targetsSummary.setTextColor(TEXT);
        } else if (n == 0) {
            targetsSummary.setText("Включён режим «только выбранные», но список пуст: звук не меняется нигде.");
            targetsSummary.setTextColor(BAD);
        } else {
            targetsSummary.setText("Только выбранные приложения: " + n + ".");
            targetsSummary.setTextColor(TEXT);
        }
    }

    private static String ago(long ms) {
        long s = Math.max(0L, ms / 1000L);
        if (s < 60L) return "только что";
        if (s < 3600L) return (s / 60L) + " мин назад";
        if (s < 86400L) return (s / 3600L) + " ч назад";
        return (s / 86400L) + " дн назад";
    }

    private void openFramework() {
        try {
            Intent i = framework == null ? null : getPackageManager().getLaunchIntentForPackage(framework[2]);
            if (i != null) {
                startActivity(i);
                return;
            }
        } catch (Throwable ignored) {
        }
        Toast.makeText(this, "У менеджера нет значка. Открой его из уведомления LSPosed/Vector "
                + "или через Magisk / KernelSU.", Toast.LENGTH_LONG).show();
    }

    // ------------------------------------------------------------------ UI helpers

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private LinearLayout.LayoutParams params(int w, int h, int top) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(w, h);
        lp.topMargin = dp(top);
        return lp;
    }

    private LinearLayout card(String title) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(16), dp(14), dp(16), dp(16));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(CARD);
        bg.setCornerRadius(dp(16));
        c.setBackground(bg);
        c.setLayoutParams(params(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 12));
        if (title != null) {
            TextView t = text(title.toUpperCase(Locale.ROOT), 11, MUTED, true);
            t.setLetterSpacing(0.08f);
            t.setPadding(0, 0, 0, dp(8));
            c.addView(t);
        }
        return c;
    }

    private void styleButton(Button b, boolean selected) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(selected ? ACCENT : CHIP);
        bg.setCornerRadius(dp(12));
        b.setBackground(bg);
        b.setTextColor(selected ? Color.WHITE : TEXT);
    }

    private Button button(String label, boolean selected) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(14);
        b.setMinHeight(dp(44));
        styleButton(b, selected);
        return b;
    }

    // ------------------------------------------------------------------ UI

    private View buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(BG);
        scroll.setFillViewport(true);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(32), dp(16), dp(32));
        scroll.addView(root, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        root.addView(text("Dophamine", 30, ACCENT, true));
        root.addView(text("Войсченджер для LSPosed / Vector: бочка и звуковой барьер", 13, MUTED, false));

        // status
        LinearLayout status = card("Проверка LSPosed / Vector");
        statusTitle = text("", 16, TEXT, true);
        statusBody = text("", 13, MUTED, false);
        statusBody.setPadding(0, dp(6), 0, 0);
        checksBox = new LinearLayout(this);
        checksBox.setOrientation(LinearLayout.VERTICAL);
        checksBox.setPadding(0, dp(10), 0, 0);
        openBtn = button("Открыть LSPosed / Vector", false);
        openBtn.setLayoutParams(params(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, 12));
        openBtn.setVisibility(View.GONE);
        openBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openFramework();
            }
        });
        Button refresh = button("Проверить ещё раз", false);
        refresh.setLayoutParams(params(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, 8));
        refresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                refreshStatus();
            }
        });
        status.addView(statusTitle);
        status.addView(statusBody);
        status.addView(checksBox);
        status.addView(openBtn);
        status.addView(refresh);
        root.addView(status);

        // target apps
        LinearLayout targetCard = card("Целевые приложения");
        targetsSummary = text("", 14, TEXT, false);
        Button pick = button("Выбрать приложения", false);
        pick.setLayoutParams(params(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, 12));
        pick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, AppsActivity.class));
            }
        });
        targetCard.addView(targetsSummary);
        targetCard.addView(pick);
        root.addView(targetCard);

        // master switch
        LinearLayout masterCard = card(null);
        master = new Switch(this);
        master.setText("Эффект включён");
        master.setTextColor(TEXT);
        master.setTextSize(16);
        master.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton b, boolean checked) {
                if (!updatingUi) prefs.edit().putBoolean(Config.K_ENABLED, checked).apply();
            }
        });
        masterCard.addView(master);
        root.addView(masterCard);

        // presets
        LinearLayout presetCard = card("Пресеты");
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout presetRow = new LinearLayout(this);
        presetRow.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < Config.PRESETS.length; i++) {
            final Config.Preset p = Config.PRESETS[i];
            Button b = button(p.name, false);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.rightMargin = dp(8);
            b.setLayoutParams(lp);
            b.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    applyPreset(p);
                }
            });
            presetButtons.add(b);
            presetRow.addView(b);
        }
        hs.addView(presetRow);
        presetCard.addView(hs);
        root.addView(presetCard);

        // sliders
        LinearLayout sliders = card("Настройки звука");
        addRow(sliders, Config.K_PITCH, "Высота голоса", DspParams.PITCH_MIN, DspParams.PITCH_MAX, FMT_SEMITONES);
        addRow(sliders, Config.K_BARREL, "Бочка", 0f, 1f, FMT_PERCENT);
        addRow(sliders, Config.K_SIZE, "Размер бочки", 0f, 1f, FMT_PERCENT);
        addRow(sliders, Config.K_LOUD, "Громкость", 0f, DspParams.LOUD_MAX, FMT_PLUS_DB);
        addRow(sliders, Config.K_BASS, "Бас", 0f, DspParams.BASS_MAX, FMT_PLUS_DB);
        addRow(sliders, Config.K_BOOM, "Звуковой удар", 0f, 1f, FMT_PERCENT);
        addRow(sliders, Config.K_GATE, "Шумодав", DspParams.GATE_MIN, DspParams.GATE_MAX, FMT_GATE);
        sliders.addView(text("Шумодав гасит фон микрофона, иначе при большой громкости он превращается в шум. "
                + "Выше +30 дБ собеседник слышит почти сплошной клиппинг, будь осторожен.", 12, MUTED, false));
        root.addView(sliders);

        // checks
        LinearLayout tests = card("Проверка");
        previewBtn = button("Записать 4 с и проиграть обработанное", false);
        previewBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startPreview();
            }
        });
        tests.addView(previewBtn);
        previewStatus = text("Играет на " + Math.round(PREVIEW_VOLUME * 100) + " % громкости, чтобы не оглушить тебя.",
                12, MUTED, false);
        previewStatus.setPadding(0, dp(6), 0, 0);
        tests.addView(previewStatus);

        testBtn = button("Самотест DSP", false);
        testBtn.setLayoutParams(params(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, 12));
        testBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                runSelfTest();
            }
        });
        tests.addView(testBtn);
        testOutput = text("", 11, TEXT, false);
        testOutput.setTypeface(Typeface.MONOSPACE);
        testOutput.setTextIsSelectable(true);
        tests.addView(testOutput);
        root.addView(tests);

        return scroll;
    }

    private final class Row {
        final String key;
        final String title;
        final float min;
        final float max;
        final int fmt;
        final TextView valueView;
        final SeekBar bar;

        Row(String key, String title, float min, float max, int fmt, TextView valueView, SeekBar bar) {
            this.key = key;
            this.title = title;
            this.min = min;
            this.max = max;
            this.fmt = fmt;
            this.valueView = valueView;
            this.bar = bar;
        }

        float value() {
            return min + (max - min) * bar.getProgress() / 1000f;
        }

        boolean is(float target) {
            return Math.abs(value() - target) <= (max - min) / 900f;
        }

        void set(float v) {
            updatingUi = true;
            bar.setProgress(Math.round((v - min) / (max - min) * 1000f));
            updatingUi = false;
            refresh();
        }

        void refresh() {
            float v = value();
            String s;
            if (fmt == FMT_SEMITONES) s = String.format(Locale.US, "%+.1f пт", v);
            else if (fmt == FMT_PERCENT) s = Math.round(v * 100f) + " %";
            else if (fmt == FMT_PLUS_DB) s = String.format(Locale.US, "+%.0f дБ", v);
            else s = v <= DspParams.GATE_OFF_DB ? "выкл" : String.format(Locale.US, "%.0f дБ", v);
            valueView.setText(s);
        }
    }

    private void addRow(LinearLayout parent, String key, String title, float min, float max, int fmt) {
        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setLayoutParams(params(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 10));
        TextView name = text(title, 14, TEXT, false);
        name.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView value = text("", 14, ACCENT, true);
        head.addView(name);
        head.addView(value);

        SeekBar bar = new SeekBar(this);
        bar.setMax(1000);
        bar.setProgressTintList(ColorStateList.valueOf(ACCENT));
        bar.setThumbTintList(ColorStateList.valueOf(ACCENT));
        bar.setLayoutParams(params(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0));

        final Row row = new Row(key, title, min, max, fmt, value, bar);
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar sb, int progress, boolean fromUser) {
                row.refresh();
                if (fromUser && !updatingUi) {
                    prefs.edit().putFloat(row.key, row.value()).apply();
                    markPreset();
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar sb) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar sb) {
            }
        });
        rows.add(row);
        parent.addView(head);
        parent.addView(bar);
    }

    private Row row(String key) {
        for (Row r : rows) if (r.key.equals(key)) return r;
        return null;
    }

    private boolean matches(Config.Preset p) {
        return row(Config.K_PITCH).is(p.pitch) && row(Config.K_BARREL).is(p.barrel)
                && row(Config.K_SIZE).is(p.size) && row(Config.K_LOUD).is(p.loud)
                && row(Config.K_BASS).is(p.bass) && row(Config.K_BOOM).is(p.boom)
                && row(Config.K_GATE).is(p.gate);
    }

    /** Highlights the preset button whose values equal the current sliders. */
    private void markPreset() {
        for (int i = 0; i < presetButtons.size(); i++) {
            styleButton(presetButtons.get(i), matches(Config.PRESETS[i]));
        }
    }

    private void loadFromPrefs() {
        DspParams p = Config.fromPrefs(prefs);
        updatingUi = true;
        master.setChecked(p.enabled);
        updatingUi = false;
        row(Config.K_PITCH).set(p.pitchSemitones);
        row(Config.K_BARREL).set(p.barrelMix);
        row(Config.K_SIZE).set(p.barrelSize);
        row(Config.K_LOUD).set(p.loudnessDb);
        row(Config.K_BASS).set(p.bassDb);
        row(Config.K_BOOM).set(p.boom);
        row(Config.K_GATE).set(p.gateDb);
        markPreset();
    }

    private void applyPreset(Config.Preset p) {
        SharedPreferences.Editor e = prefs.edit();
        Config.put(e, p);
        e.putBoolean(Config.K_ENABLED, true);
        e.apply();
        loadFromPrefs();
    }

    // ------------------------------------------------------------------ self test

    private void runSelfTest() {
        testBtn.setEnabled(false);
        testOutput.setTextColor(TEXT);
        testOutput.setText("Идёт самотест…");
        new Thread(new Runnable() {
            @Override
            public void run() {
                final DspSelfTest.Result r = DspSelfTest.run(true);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        testOutput.setText(r.text);
                        testOutput.setTextColor(r.ok ? GOOD : BAD);
                        testBtn.setEnabled(true);
                    }
                });
            }
        }, "dophamine-selftest").start();
    }

    // ------------------------------------------------------------------ mic preview

    private void startPreview() {
        if (previewRunning) return;
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
            return;
        }
        previewRunning = true;
        previewBtn.setEnabled(false);
        final DspParams params = Config.fromPrefs(prefs);
        new Thread(new Runnable() {
            @Override
            public void run() {
                runPreview(params);
            }
        }, "dophamine-preview").start();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQ_MIC) return;
        if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) startPreview();
        else previewStatus.setText("Без доступа к микрофону проверка невозможна (сам модуль в звонках это не затрагивает).");
    }

    private void say(final String s) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                previewStatus.setText(s);
            }
        });
    }

    private void runPreview(DspParams params) {
        final int sr = 44100;
        AudioRecord rec = null;
        AudioTrack track = null;
        try {
            int minIn = AudioRecord.getMinBufferSize(sr, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
            if (minIn <= 0) {
                say("Микрофон не поддерживает 44.1 кГц моно.");
                return;
            }
            rec = new AudioRecord(MediaRecorder.AudioSource.MIC, sr, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, Math.max(minIn, 8192) * 2);
            if (rec.getState() != AudioRecord.STATE_INITIALIZED) {
                say("Не удалось открыть микрофон (его занял другой процесс?).");
                return;
            }
            int total = sr * 4;
            short[] pcm = new short[total];
            BufferProcessor bp = new BufferProcessor();
            Object key = new Object();
            say("Говори… (4 секунды)");
            rec.startRecording();
            int pos = 0;
            while (pos < total) {
                int n = rec.read(pcm, pos, Math.min(2048, total - pos));
                if (n <= 0) break;
                bp.processShorts(key, pcm, pos, n, sr, 1, params);
                pos += n;
            }
            rec.stop();
            if (pos <= 0) {
                say("Микрофон ничего не отдал.");
                return;
            }
            say("Играю обработанное…");
            int minOut = AudioTrack.getMinBufferSize(sr, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT);
            int bufBytes = Math.max(minOut, 8192);
            track = new AudioTrack(AudioManager.STREAM_MUSIC, sr, AudioFormat.CHANNEL_OUT_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, bufBytes, AudioTrack.MODE_STREAM);
            track.setStereoVolume(PREVIEW_VOLUME, PREVIEW_VOLUME);
            track.play();
            track.write(pcm, 0, pos);
            track.stop();
            // stop() lets queued data drain; wait for at most one buffer before releasing
            long wait = Math.min(pos * 1000L / sr, (bufBytes / 2) * 1000L / sr) + 300;
            Thread.sleep(wait);
            say("Готово. Можно ещё раз.");
        } catch (Throwable t) {
            say("Ошибка проверки: " + t);
        } finally {
            try {
                if (rec != null) rec.release();
            } catch (Throwable ignored) {
            }
            try {
                if (track != null) track.release();
            } catch (Throwable ignored) {
            }
            previewRunning = false;
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    previewBtn.setEnabled(true);
                }
            });
        }
    }
}
